import java.util.List;
import java.util.Scanner;
import java.util.Vector;


public class NameTest {

	
	public static void main(String[]args)
	{
		Name n;
		
		List<Name> vec = new Vector<>();
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		int ch;
		do{
		System.out.println("Enter your choice : ");
		System.out.println("1. Enter first name and last name");
		System.out.println("2. Display Names");
		System.out.println("3.Exit");
		
		ch = sc.nextInt();
				
		switch(ch)
		{
		case 1: ///enter full name
			System.out.println("Enter first name : ");
			
			String fname = sc1.nextLine();
			
			System.out.println("Enter last name : ");
			
			String lname = sc2.nextLine();
					
			n = new Name(fname,lname);
			vec.add(n);
			
			break;
		case 2: ///display list of names
			System.out.println(vec);
			break;
		case 3: ///exit
			break;
		default:
			break;
		}
		
		
		}while(ch!=3);
		
		sc.close();
		sc1.close();	
		sc2.close();
	}
	
}
