import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class NameList {
public static void main(String args[])
{
	List <String> names = new ArrayList<>();
	names.add("Alinda");
	names.add("Rhea");
	names.add("Pink");
	names.add("Katy");
	names.add("Riri");
	
	System.out.println("Enter a name  ");
	Scanner sc = new Scanner(System.in);
	String str = sc.nextLine();
	
	if(names.contains(str))
		System.out.println(str+" Is present in the list.");
}
}
