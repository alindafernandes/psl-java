import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;


public class ProductTest {

	public static void main(String [] args)
	{
		Product pro[] = new Product[10];
		
		pro[0] = new Product();
		pro[0].setProductId("P001");
		pro[0].setProductName("Maruti800");
		
		pro[1] = new Product();
		pro[1].setProductId("P002");
		pro[1].setProductName("MarutiZen");
		
		pro[2] = new Product();
		pro[2].setProductId("P003");
		pro[2].setProductName("MarutiEsteem");
		
		pro[3] = new Product();
		pro[3].setProductId("P004");
		pro[3].setProductName("MarutiAlto");
		
		pro[4] = new Product();
		pro[4].setProductId("P005");
		pro[4].setProductName("MarutiSwift");
		
		pro[5] = new Product();
		pro[5].setProductId("P006");
		pro[5].setProductName("MarutiSwiftDzire");
		
		pro[6] = new Product();
		pro[6].setProductId("P007");
		pro[6].setProductName("MarutiCelerio");
		
		pro[7] = new Product();
		pro[7].setProductId("P008");
		pro[7].setProductName("MarutiOmni");
		
		pro[8] = new Product();
		pro[8].setProductId("P009");
		pro[8].setProductName("MarutiWagonR");
		
		pro[9] = new Product();
		pro[9].setProductId("P010");
		pro[9].setProductName("MarutiVitaraBrezza");
		
		Map<String,String> hash = new Hashtable<>();
		
		for(int i=0;i<10;i++)
		{
			hash.put(pro[i].getProductId(),pro[i].getProductName());
		}
		
		System.out.println("Enter productid to search : ");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		sc.close();
		
		if(hash.containsKey(str))
				System.out.println(hash.get(str));
		else
			System.out.println("Wrong id");
		
		System.out.println("Enter productid to search : ");
		Scanner sc1 = new Scanner(System.in);
		String str1 = sc1.nextLine();
		sc1.close();
		
		hash = new TreeMap<>(hash);
		
		if(hash.containsKey(str1))
		{
			hash.remove(str1);
			System.out.println("After deleting "+ str1+" : "+hash);
		}
	else
		System.out.println("This product doesn't exist");
	}
	
}
