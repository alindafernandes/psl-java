import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MoviesBooking {

	public void insertValues(String s) 
	{
		String sp[] = s.split(",");
		Connection con = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest","root","");
					
			Statement stmt =con.createStatement();
						
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
			Date d =null;
			
		
				d = sdf.parse(sp[3]);
			
			java.sql.Date data = new java.sql.Date(d.getTime());
			
			String query = "insert into movies value("+Integer.parseInt(sp[0])+",'"+sp[1]+"','"+sp[2]+"','"+data+"')";
			
			int i = stmt.executeUpdate(query);
			if(i>0)
				System.out.println("record inserted");
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String args[])
	{
		MoviesBooking m = new MoviesBooking();
		
		BufferedReader br;
			try {
				br = new BufferedReader(new FileReader("movies"));
				
				StringBuffer sb = new StringBuffer();
				
				String line=null;
				String str=null;
				
				try {
					while((line=br.readLine())!=null)
					{
						sb.append(line).append("\n");
						str=line;
						m.insertValues(str);
					}
						
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		catch (FileNotFoundException e1) 
		{
			e1.printStackTrace();
		}
	}
	
}
