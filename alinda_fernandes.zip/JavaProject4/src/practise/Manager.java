package practise;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Manager extends Employee implements Serializable{
	

	public Manager(int empId, String name, String location) {
		super(empId, name, location);
		// TODO Auto-generated constructor stub
	}

	public static void main(String args[])
	{
		Employee emp = new Employee(34,"abc","lon");
		
		ObjectInputStream in = null;
		
		try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream("manf"))){
		in=new ObjectInputStream(new FileInputStream("manf"));
		out.writeObject(emp);
		System.out.println("Object is written to file");
		try {
			System.out.println((Employee)in.readObject());
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		}
		catch(IOException e){
			e.printStackTrace();
			
		}
		
	}
}
