package practise;

public class Address {

}
