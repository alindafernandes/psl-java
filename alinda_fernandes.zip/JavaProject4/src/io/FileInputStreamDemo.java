package io;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String args[])
	{
		FileInputStream fi = null;
		
		try{
		fi = new FileInputStream("file");
		
		//int data = fi.read();  ///reads one byte(1 char) of file
		//System.out.println(data);  ///returns ASCII value for that char
		//System.out.println((char)data);  ///returns char
		
		
		int data;
		while((data=fi.read())!=-1)
			System.out.print((char)data); 
		

		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(fi!=null) ////to check if file exists and fi is not null..
			{
				try{
					fi.close(); ////if fi not null then only close fi
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		
	}
}
