package io;

import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;



public class DataOutputStreamDemo {

	public static void main(String [] args)
	{
		FileOutputStream fo = null;  ///knows to write
		DataOutputStream dout = null; ////knows to deal with primitives
		try{
			
		fo = new FileOutputStream("data");
		dout = new DataOutputStream(fo);
		dout.writeInt(10);
		dout.writeChar('c');
		dout.writeDouble(5.6d);
		System.out.println("primitives written to file");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				if(fo!=null)
					fo.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
