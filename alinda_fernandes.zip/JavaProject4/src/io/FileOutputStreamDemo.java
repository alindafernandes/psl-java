package io;

import java.io.FileOutputStream;
import java.io.IOException;


public class FileOutputStreamDemo {
	public static void main(String args[])
	{
		String str = "Ola Goa!!";
		
		FileOutputStream fo= null;
		
		try
		{
			fo = new FileOutputStream("file2",true);
			byte b[] = str.getBytes();
			fo.write(b);
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(fo!=null)
					fo.close();
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
	}

}
