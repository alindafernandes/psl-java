package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectInputStreamdemo {
	public static void main(String [] args)
	{
		
		ObjectInputStream in = null;
		try{
		
			in= new ObjectInputStream(new FileInputStream("string"));
			try {
				String str =(String)in.readObject();
				System.out.println(str);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				if(in!=null)
					in.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
