package io;

import java.io.Serializable;

public class Employee implements Serializable{

	private int empId;
	private String name;
	private String location;
	
	public Employee(int empId, String name, String location)
	{
		this.empId = empId;
		this.name=name;
		this.location=location;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", location="
				+ location + "]";
	}
	
}
