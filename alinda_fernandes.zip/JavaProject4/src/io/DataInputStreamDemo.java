package io;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class DataInputStreamDemo {

	public static void main(String [] args)
	{
		FileInputStream fi = null;  ///knows to write
		DataInputStream din = null; ////knows to deal with primitives
		try{
			
		fi = new FileInputStream("data");
		din = new DataInputStream(fi);
		int i =din.readInt();
		char c= din.readChar();
		double d=din.readDouble();
		System.out.println(i+" "+c+" "+d);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				if(fi!=null)
					fi.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
