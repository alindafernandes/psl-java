package io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectOutputStreamDemo {
	public static void main(String [] args)
	{
		String str = "this is string object";
		ObjectOutputStream out = null;
		try{
		
			out= new ObjectOutputStream(new FileOutputStream("string"));
			out.writeObject(str);
			System.out.println("String is written to file");
		}
		catch(IOException e){
			e.printStackTrace();
		}
		finally
		{
			try{
				if(out!=null)
					out.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
