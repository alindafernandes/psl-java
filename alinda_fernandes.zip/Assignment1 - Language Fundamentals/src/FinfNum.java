import java.util.Scanner;
public class FinfNum {
	
	
	static int findPosition(int num,int[] nos)
	{
		for(int i = 0; i<nos.length; i++)
		{
			if(nos[i]==num)
				return ++i;
		}
		return -1;
	}
	
	public static void main(String args[])
	{
		int arr[]= {12,56,35,9,67,45,2,68,3,8,21};
						
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int val = findPosition(a, arr);
		System.out.println(val);
	}

}
