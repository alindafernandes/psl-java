import java.util.Scanner;

public class Prime 
{
	
	static int [] findPrimes(int a,int b)
	{
		int arr[]=new int[b+1];
		int primes[]=new int[1000];
		int k=0;
		if(a<=2)
			primes[k++]=2;
		for(int i=3;i<=b;i=i+2)
		{
			if(arr[i]!=0)
				continue;
			if(i>=a)
			primes[k++]=i;
			int num=i+i;
			while(num<=b)
			{
				arr[num]=1;
				num+=i;
			}
		}
		return primes;
	}
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt(); //from
		int b=sc.nextInt(); //to
		int primes[]=findPrimes(a, b);
		for(int x=0;primes[x]!=0;x++)
			System.out.print(" "+primes[x]);
	}

}





