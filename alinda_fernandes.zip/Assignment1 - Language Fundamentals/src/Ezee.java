import java.util.Scanner;
public class Ezee {
	
	static String[] initProductNames()
	{
		String list[] = {"book","pen","bottle","phone","glass"};
		return list;		
	}
	static boolean isPresent(String[] productNames, String keyword)
	{
		for(String c : productNames)
		{
			if(c.equals(keyword))
					return true;
		}
			return false;
	}

	public static void main(String args[])
	{
		String s[]=initProductNames();
		
		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		
		boolean val = isPresent(s,a);
		
		System.out.println(val);
	}
	
}
