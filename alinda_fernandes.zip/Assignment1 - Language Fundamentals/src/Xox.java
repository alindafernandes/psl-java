import java.util.Scanner;


public class Xox {
	
		public static void main(String[] args) {
		
			
			char arr[][] = new char[3][3];
			int n;
			System.out.println("..enter the Square no (1-9)");
			for(int i=1;i<10;i++)
			{
				if(i%2!=0)
					System.out.println("Turn : X ");
				else
					System.out.println("Turn : O ");
				
				Scanner sc=new Scanner(System.in);
				n = sc.nextInt();
				if(i%2!=0)
				{
				if(n==1)
				{
					
						arr[0][0]='x';
				}
					
				if(n==2)
				{
					
						arr[0][1]='x';
				}
				if(n==3)
				{
					
						arr[0][2]='x';
				}
					
				if(n==4)
				{
						arr[1][0]='x';
				}
				if(n==5)
				{
					
						arr[1][1]='x';
				}
					
				if(n==6)
				{
					arr[1][2]='x';
				}
				if(n==7)
				{
					arr[2][0]='x';
				}
				if(n==8)
				{
					arr[2][1]='x';
				}
				if(n==9)
				{
					arr[2][2]='x';
				}
				
				}
				else
				{
					
					if(n==1)
					{
							arr[0][0]='o';
					}
						
					if(n==2)
					{
						
						arr[0][1]='o';
					}
					if(n==3)
					{
						
						arr[0][2]='o';
					}
						
					if(n==4)
					{
						arr[1][0]='o';
					}
					if(n==5)
					{
						
						arr[1][1]='o';
					}
						
					if(n==6)
					{
						arr[1][2]='o';
					}
					if(n==7)
					{
						arr[2][0]='o';
					}
					if(n==8)
					{
						arr[2][1]='o';
					}
					if(n==9)
					{
						arr[2][2]='o';
					}
				}//end else
			}//end for
			char c;
			//horizontal
			for(int i=0;i<3;i++)
			{
				if(arr[i][0]==arr[i][1]&& arr[i][1]==arr[i][2])
				{
					c=arr[i][1];
					System.out.println(c +" wins..H");
				}
			}
			//vertical
			for(int i=0;i<3;i++)
			{
				
				if(arr[0][i]==arr[1][i]&& arr[1][i]==arr[2][i])
				{
					c=arr[1][i];
					System.out.println(c +" wins..V");
				}
			}
			//diagonal
			//horizontal
			
				if((arr[0][0]==arr[1][1]&& arr[1][1]==arr[2][2])||(arr[0][2]==arr[1][1]&& arr[1][1]==arr[2][0]))
				{
					c=arr[1][1];
					System.out.println(c +" wins..D");
				}
			
		}
}
