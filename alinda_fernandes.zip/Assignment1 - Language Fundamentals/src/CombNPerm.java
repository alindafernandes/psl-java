
public class CombNPerm {
	
	static int count=0;
	static String [] combi=new String [10000];
	
	 static String[] combinations(String pre,String str)
	{
		int n=str.length();
		if(n==0)
		{
			combi[count++]=pre;
			return combi;
		}
		for(int i=0;i<n;i++)
		{
			combinations(pre+str.charAt(i),str.substring(0,i)+str.substring(i+1));
		}
		return combi;
	}

	public static void main(String args[])
	{
		
		String s="123";
		String combination[]=combinations("", s);
		for(int i=0;i<count;i++)
		{
			System.out.println(combination[i]);
		}
		
	}
	
}
