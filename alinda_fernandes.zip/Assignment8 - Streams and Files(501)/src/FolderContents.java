import java.io.File;
import java.io.IOException;


public class FolderContents {
	
	public static void displayFolderContents(String path)
	{
		File f = new File(path);
		File[] list = f.listFiles();
		for(File file : list)
		{
			try 
			{
			if(file.isDirectory())
			{
				displayFolderContents(file.getAbsolutePath());
			}
			else
				System.out.println(file.getCanonicalPath());
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}	
	}
	
	public static void main(String args[])
	{
		displayFolderContents("C://Users/alinda_fernandes/Assignment8 - Streams and Files(501)");
	}
}
