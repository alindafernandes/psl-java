import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Words {

	public static int countWords(String filePath)
	{
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(filePath));
			
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String msg=null;
			int len=0;
			try {
				while((line=br.readLine())!=null)
				{
					sb.append(line).append(" ");
					msg = line;
					System.out.println(msg);
					String words[] = msg.split(" ");
					for(String s : words)
					{
						len++;
					}
				}
				
				return len;
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
		
		return 0;
	}
	
	public static void main(String args[])
	{
		String filePath = "file";
		int len = countWords(filePath);
		System.out.println("There are "+len+" words in the file");
	}
}
