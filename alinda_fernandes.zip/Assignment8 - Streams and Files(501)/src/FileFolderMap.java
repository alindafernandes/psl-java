import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class FileFolderMap {

	public static Map<String,List<String>> map = new TreeMap<>();
	
	public static void displayFolderContents(String path)
	{
		List <String> list = new ArrayList<>();
		File file = new File(path);
		File[] files = file.listFiles();
		
		for(File f : files)
		{
			if(f.isDirectory())
			{
				displayFolderContents(f.getAbsolutePath());
			}
		}
		for(File f : files)
		{
			if(f.isFile())
			{
				list.add(f.getName());
				
			}	
		}
		map.put(file.getName(), list);
	}

	public static void main(String args[])
	{	
		displayFolderContents("C://Users/alinda_fernandes/Assignment8 - Streams and Files(501)");
	
		System.out.println("Map of Folder - Files");
		System.out.println(".....................");
		for(Map.Entry entry : map.entrySet())
			System.out.println(entry.getKey()+" "+entry.getValue());
	}
	
}
