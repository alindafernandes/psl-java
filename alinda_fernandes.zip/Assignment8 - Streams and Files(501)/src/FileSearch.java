import java.io.File;

public class FileSearch {
	
	public static boolean check;
	
	public static boolean searchFile(String path, String filename)
	{		
		File f = new File(path),f1=new File(filename);
		File[] list = f.listFiles();
		for(File file : list)
		{
			if((file.getName().compareTo(filename))==0)
			{
				check = true;
				System.out.println(file.getAbsolutePath());
			}
			else if(file.isDirectory())
			{
				searchFile(file.getAbsolutePath(),filename);
			}
		}
		return check;
	}
	
	public static void main(String args[])
	{
		String path = "C://Users/alinda_fernandes";
		String filename = "Words.class";
		boolean check = searchFile(path,filename);
		
		if(check == true)
			System.out.println("File is found");
		else
			System.out.println("File not found");
	}
}
