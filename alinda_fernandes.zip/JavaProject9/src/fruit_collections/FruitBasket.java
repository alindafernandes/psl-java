package fruit_collections;

import java.util.HashMap;
import java.util.Map;

public class FruitBasket {

	public enum Fruits{
		MANGO (5), ORANGE(3), PINEAPPLE(5), GRAPES(4), POMEGRANATE(2);
		int val;
		
		Fruits(int val)
		{
			this.val=val;
		}
		
		private int getVal()
		{
			return val;
		}
	}
	
	public static void main(String args[])
	{
		//Map <String,Integer> fruit1 = new HashMap();
		Map<Enum,Integer> fruit1 = new HashMap<>();
		Fruits f=null; 
		
		fruit1.put(f.GRAPES, 10);
		fruit1.put(f.ORANGE, 5);
		fruit1.put(f.MANGO, 10);
		
		int total=0;
		for(Map.Entry<Enum,Integer> entry : fruit1.entrySet())
			{
				System.out.println(entry.getKey()+" "+entry.getValue());
			}
		
		/*fruit1.put("orange",5);
		fruit1.put("mango",10);
		fruit1.put("pomegranate",3);
		fruit1.put("grapes",1);
		fruit1.put("pineapple",2);
		*/
		
		
		//System.out.println("Fruit1 :");
		//for(Map.Entry<String,Integer> entry : fruit1.entrySet())
		//{
		//	System.out.println(entry.getKey()+" "+entry.getValue());
		//}
		//System.out.println("**********************");
		
		Map<Integer,Map<String,Integer>> basket = new HashMap<>();
		
		//basket.put(1, fruit1);
	
		Map <String,Integer> fruit2 = new HashMap();
		
		
		fruit2.put("orange",15);
		fruit2.put("mango",1);
		fruit2.put("pomegranate",5);
		fruit2.put("grapes",10);
		fruit2.put("pineapple",2);
		
		System.out.println("Fruit2 :");
		for(Map.Entry<String,Integer> entry : fruit2.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		System.out.println("**********************");
		basket.put(2, fruit2);
		
		Map <String,Integer> fruit3 = new HashMap();
		
		
		fruit3.put("orange",1);
		fruit3.put("mango",3);
		fruit3.put("pomegranate",8);
		fruit3.put("grapes",5);
		fruit3.put("pineapple",5);
		
		System.out.println("Fruit3 :");
		for(Map.Entry<String,Integer> entry : fruit3.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		System.out.println("**********************");
		basket.put(3, fruit3);
		
		for(Map.Entry<Integer, Map<String,Integer>> entry : basket.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
			System.out.println("**********************");
		}
		
	}
	
}
