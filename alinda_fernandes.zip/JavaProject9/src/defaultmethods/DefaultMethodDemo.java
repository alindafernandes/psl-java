package defaultmethods;

public class DefaultMethodDemo {

	public static void main(String args[])
	{
		Animal a = new Cat();
		a.eat();
		a.speak();
		a.legs("Cat");
		
		a = new Dog();
		a.eat();
		a.speak();
		a.legs("Dog");
		
		a = new Bird();
		a.eat();
		a.speak();
		a.legs("Bird");
	}
	
}
