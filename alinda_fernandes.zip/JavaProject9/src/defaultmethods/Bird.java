package defaultmethods;

public class Bird implements Animal{

	@Override
	public void eat() {
		System.out.println("Worms");
	}

	@Override
	public void speak() {
		System.out.println("Chirps");
	}

	@Override
	public void legs(String name) {
		System.out.println(name+" has 2 legs");
	}

}
