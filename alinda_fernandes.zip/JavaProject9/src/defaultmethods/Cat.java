package defaultmethods;

public class Cat implements Animal{

	@Override
	public void eat() {
		System.out.println("Fish");
	}

	@Override
	public void speak() {
		System.out.println("Meow");
	}

}
