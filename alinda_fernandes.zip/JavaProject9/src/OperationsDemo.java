
public class OperationsDemo {

	public static void main(String args[])
	{
		Operation o;
		
		o = (int a, int b)->{return a+b;};
		System.out.println("Addition of 5,5 : "+o.operations(5, 5));
		
		o = (int a, int b)->a-b;
		System.out.println("Subtraction of 5,5 : "+o.operations(5, 5));
		
		o = (int a, int b)->{return a*b;};
		System.out.println("Multiplication of 5,5 : "+o.operations(5, 5));
		
		o = (int a, int b)->{return a/b;};
		System.out.println("Division of 5,5 : "+o.operations(5, 5));
		
		o = (int a, int b)->{return a%b;};
		System.out.println("Remainder of 5/5 : "+o.operations(5, 5));
	}
	
}
