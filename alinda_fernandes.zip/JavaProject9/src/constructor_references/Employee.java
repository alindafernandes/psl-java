package constructor_references;

public class Employee {

	private String name;
	private Integer age;
	
	public Employee()
	{
		name="abx";
		age=23;
	}

	public Employee(String name, Integer age) {
	
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public Integer getAge() {
		return age;
	}

}
