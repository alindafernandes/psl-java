package constructor_references;

public interface EmployeeProvider1 {

	Employee getEmployee(String name, Integer age);
}
