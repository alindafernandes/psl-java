package constructor_references;

public interface EmployeeProvider2 {
	
	Employee getEmployee();
}
