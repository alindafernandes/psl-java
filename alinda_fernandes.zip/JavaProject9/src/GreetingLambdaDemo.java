
public class GreetingLambdaDemo {

	public static void main(String args[])
	{
		Greetings g;
		
		//g = ()-> System.out.println("Good Morning");
		//g.greet();
		
		//g = (n)->System.out.println("Good Morning "+n); 
		//g.greet("Alinda");
		
		//g = ()-> "Good Morning";
		//g.greet();
		//System.out.println(g.greet()); ////just to print the returned value
		
		g = (n)-> "Good Morning "+n;
		System.out.println(g.greet("Alinda"));
		
		//g = ()-> System.out.println("Good Night");
		//g.greet();
		
		//g = (String n)->System.out.println(n); 
		//g.greet("Good Night");
		
		//g=()->{return "Good night";}; ///braces mandatory for return statement or when there are multiple statements to be executed
		//System.out.println(g.greet()); ////just to print the returned value
		
		g = (String n)->{return "Good Night "+n;};
		System.out.println(g.greet("Alinda"));
	}
	
}
