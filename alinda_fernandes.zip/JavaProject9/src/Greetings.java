
public interface Greetings {

	//public void greet();
	
	//public void greet(String name);
	
	//public String greet();
	
	public String greet(String name);
}
