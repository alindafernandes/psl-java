package wildcards;

import java.util.ArrayList;
import java.util.List;

public class WildCardTest {

	public static void main(String args[])
	{
		List<?> list = new ArrayList<>();
		
	}
	
}
