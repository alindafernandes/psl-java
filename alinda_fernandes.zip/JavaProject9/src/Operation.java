
public interface Operation {

	public int operations(int a, int b);
	
}
