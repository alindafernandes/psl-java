package methodreferences;

public class Person {

	private Integer age;
	String name;
	
	public Person()
	{
		
	}
	
	public Person(String name,Integer age)
	{
		this.age=age;
		this.name = name;
	}
	
	public Integer getAge()
	{
		return age;
	}
	
	public String getName()
	{
		return name;
	}

	@Override
	public String toString() {
		return "Person [Name : "+name+",Age : "+age+"]";
	}
	
	public int compareByAge(Person a,Person b){
		return a.age.compareTo(b.age);
	}
	
	public int compareByName(Person a,Person b){
		return a.name.compareTo(b.name);
	}
	
	public static int sortByAge(Person a,Person b){
		return a.age.compareTo(b.age);
	}
	
	public static int sortByName(Person a,Person b){
		return a.name.compareTo(b.name);
	}
}
