package methodreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PersonInstanceMethodReference {

	public static void main(String args[])
	{
		List<Person> list = new ArrayList<>();
		
		list.add(new Person("A",21));
		list.add(new Person("Z",56));
		list.add(new Person("J",43));
		list.add(new Person("U",18));
		list.add(new Person("P",39));
		
		for(Person per : list)
			System.out.println(per);
		System.out.println("...........................");
		
		Person p = new Person();
		
		Collections.sort(list, p::compareByName);
		System.out.println("After sorting by Name :");
		for(Person per1 : list)
			System.out.println(per1);
		System.out.println("...........................");
		
		Collections.sort(list, p::compareByAge);
		System.out.println("After sorting by Age :");
		for(Person per2 : list)
			System.out.println(per2);
		System.out.println("...........................");
		
	}
	
}
