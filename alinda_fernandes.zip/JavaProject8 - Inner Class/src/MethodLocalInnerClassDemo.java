
public class MethodLocalInnerClassDemo {

	void mymethod()
	{
		int num=23;
		
		class MethodInnerDemo
		{
			public void print()
			{
				System.out.println("this is inner class method");
			}
		}
		
		MethodInnerDemo mid = new MethodInnerDemo();
		mid.print();
	}
	
	public static void main(String args[])
	{
		MethodLocalInnerClassDemo demo = new  MethodLocalInnerClassDemo();
		demo.mymethod();
	}
	
}
