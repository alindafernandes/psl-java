

class Outer_Class
{
	private int num = 175; ///private var of outer class
	
	public class Inner_Class ///inner class
	{
		public int getNum()
		{
			int icnum = 15;
			System.out.println("This is the getnum method of the inner class");
			return num;
		}
	}
	public void getinnerNum()
	{
		
		System.out.println("This is the method of the outer class");
		
	}
}


public class InnerClassDemo 
{
	public static void main(String args[])
	{
		Outer_Class oc =new Outer_Class();
		
		Outer_Class.Inner_Class ic = oc.new Inner_Class();
		
		System.out.println(ic.getNum());
		
		oc.getinnerNum();
	}
}
