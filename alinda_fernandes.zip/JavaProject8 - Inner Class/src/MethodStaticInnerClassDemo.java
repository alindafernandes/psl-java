
public class MethodStaticInnerClassDemo {

	static void display()
	{
		int num=16;
		
		class  MethodInner
		{
			 public void print()
			 {
				 System.out.println("this is inner class method");
			 }
		}
	
		 MethodInner mi = new MethodInner();
			mi.print();
	}
	
	public static void main(String args[])
	{
		MethodStaticInnerClassDemo demo = new  MethodStaticInnerClassDemo();
		demo.display();
	}
}
