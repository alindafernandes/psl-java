abstract class AnonymousInner{
	public abstract void mymethod();
	public abstract void test();
}
public class AnonymousClassDemo {

	public static void main(String args[])
	{
		AnonymousInner inner = new AnonymousInner(){
			public void mymethod()
			{
				System.out.println("example of Anonymous inner class");
			}
		public void test()
		{
			
		}
	};
	
	inner.mymethod();
	inner.test();
	
	}
}
