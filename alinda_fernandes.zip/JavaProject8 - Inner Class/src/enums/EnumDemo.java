package enums;

public class EnumDemo {

	
	public static void main(String args[])
	{
		double cost = 200;
		
		Transactions t = Transactions.CASH;
		
		EnumDemo e = new EnumDemo();
	}
}
