package calendar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarDemo {

	
	public static void datefunction(Date d1)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(d1);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		Date d;
		
		try {
			d = sdf.parse("17-10-2016");
			boolean isbefore = d1.before(d);
			System.out.println(isbefore);
			boolean isafter = d1.after(d);
			System.out.println(isafter);
			boolean isequal = d1.equals(d);
			System.out.println(isequal);
			
			cal.add(Calendar.DATE, 7);
			System.out.println(cal.get(cal.DATE));
			System.out.println(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String args[])
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		try {
		Date d = sdf.parse("25-04-2016");
		
		datefunction(d);
		
		java.sql.Date sqldate = java.sql.Date.valueOf("2016-10-07");
		System.out.println(sqldate);
		java.util.Date utildate = new java.util.Date(sqldate.getTime());
		System.out.println(utildate);	
		
		java.util.Date newutildate = sqldate;
		System.out.println(newutildate);	
		
		
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
