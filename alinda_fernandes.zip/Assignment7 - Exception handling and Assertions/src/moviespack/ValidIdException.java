package moviespack;

public class ValidIdException extends Exception{

	public ValidIdException(String msg)
	{
		super(msg);
	}
}
