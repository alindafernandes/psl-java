package moviespack;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Movies {
	public enum Language{
		ENGLISH("English"),HINDI("Hindi"),MARATHI("Marathi");
		
		private String lang;
		
		private Language(String l)
		{
			this.lang=l;
		}

		@Override
		public String toString() {
			
			return lang;
		}
	}
	
	public void values(String s) throws NoofValuesException {
		
		String sp[] = s.split(",");
		
		if(sp.length>4){
			throw new NoofValuesException("No. of values exceeded in line "+"'"+s+"'");
		}
	}
	
	public void langValues(String s) throws LanguageException {
		String sp[] = s.split(",");
		
		Language l[] = Language.values();		
		int hit=0;
			for(Language lang : l)
			{
				if(((lang.toString()).compareTo(sp[2]))==0)
					hit++;
			}
		if(hit==0)
			throw new LanguageException("Invalid Language  '"+sp[2]+"'  at line "+s);
	}
	
	public void validId(String s) throws ValidIdException {
		String sp[] = s.split(",");
		//int i = Integer.parseInt(sp[0]);
		if(sp[0].length()>1)
			throw new ValidIdException("Invalid Movie ID  '"+sp[0]+"' at line "+s);
	}
	
	public static void main(String args[])
	{
		Movies m = new Movies();
			
	BufferedReader br;
	try {
		br = new BufferedReader(new FileReader("movies"));
		
		StringBuffer sb = new StringBuffer();
		
		String line=null;
		String str=null;
		
		try {
			while((line=br.readLine())!=null)
			{
				sb.append(line).append("\n");
				str=line;
				m.values(str);
				m.langValues(str);
				m.validId(str);
			}
				
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		catch (NoofValuesException e1) {
			
			e1.printStackTrace();
		} catch (LanguageException e1) {
			
			e1.printStackTrace();
		} 
		catch (ValidIdException e1) {
			
			e1.printStackTrace();
		}
		
	} 
	catch (FileNotFoundException e1) {
		
		e1.printStackTrace();
	} 
	
	
	}
}
