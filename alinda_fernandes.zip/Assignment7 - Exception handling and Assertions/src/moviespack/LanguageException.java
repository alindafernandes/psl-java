package moviespack;

public class LanguageException extends Exception{

	public LanguageException(String msg)
	{
		super(msg);
	}
}
