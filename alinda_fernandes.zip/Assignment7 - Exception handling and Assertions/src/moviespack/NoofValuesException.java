package moviespack;

public class NoofValuesException extends Exception{

	public NoofValuesException(String msg)
	{
		super(msg);
	}
}
