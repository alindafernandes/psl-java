package contacts;

public class StackFullorUninitialized extends Exception{

	public StackFullorUninitialized(String msg)
	{
		super(msg);
	}
}
