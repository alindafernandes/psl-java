package contacts;

import java.util.Date;

public class Contact2 {
	private String First_name, Last_name;
	
	private String Address, Email;
	
	private long Mobile;

	public Contact2(String first_name, String last_name, String address, String email, long mobile) 
	{
		First_name = first_name;
		Last_name = last_name;
		Address = address;
		Email = email;
		Mobile = mobile;
	}

	@Override
	public String toString() {
		return "[Contact2 ["+First_name+","+Last_name+","+Address+","+Email+","+Mobile+"]]";
	}
	
	
}
