package contacts;

public class UninitializedOrEmptyStack extends Exception{

	public UninitializedOrEmptyStack(String msg)
	{
		super(msg);
	}
	
}
