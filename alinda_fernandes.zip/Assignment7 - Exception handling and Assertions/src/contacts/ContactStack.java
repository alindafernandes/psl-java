package contacts;

import java.util.Stack;

public class ContactStack {

	public static void main(String args[])
	{
		Contact2 c = new Contact2("alinda","fernandes","fatorda","abc@xyz.com",123456);
		Contact2 c1 = new Contact2("briana","pereira","goa","erty@xyz.com",456789);
		Contact2 c2 = new Contact2("aish","rana","vasco","iopo@xyz.com",753691);
		Contact2 c3 = new Contact2("joy","paes","panjim","joy@xyz.com",951374);
		
		Stack<Contact2> stack = new Stack<>();
		
		stack.push(c);
		stack.push(c1);
		stack.push(c2);
		stack.push(c3);
		System.out.println(stack);
		while(stack.isEmpty()!=true)
			System.out.println(stack.pop());
	}
	
}
