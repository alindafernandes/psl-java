package contacts;

public class ContactInvalidation extends Exception{

	public ContactInvalidation(String msg)
	{
		super(msg);
	}
}
