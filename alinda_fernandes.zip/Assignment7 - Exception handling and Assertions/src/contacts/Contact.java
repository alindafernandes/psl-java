package contacts;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Contact {
	private String First_name, Middle_name, Last_name;
	private Date Date_of_birth, Anniversary;
	private String Gender, Address, Area, City,  State, Country, Email, Website;
	private int Pincode;
	private long Telephone=0, Mobile=0;
	
	
	public Contact(String first_name, String middle_name, String last_name,
			Date date_of_birth, Date anniversary, String gender,
			String address, String area, String city, String state,
			String country, String email, String website, int pincode,
			long telephone, long mobile) {
		
		First_name = first_name;
		Middle_name = middle_name;
		Last_name = last_name;
		Date_of_birth = date_of_birth;
		Anniversary = anniversary;
		Gender = gender;
		Address = address;
		Area = area;
		City = city;
		State = state;
		Country = country;
		Email = email;
		Website = website;
		Pincode = pincode;
		Telephone = telephone;
		Mobile = mobile;
	}	
	
	
	@Override
	public String toString() {
		
		return "[Contact : ["+First_name+", "+Last_name+", "+Date_of_birth+", "+Gender+", "+ Address+", "+ State+", "+ Country+", " +Email+", "+Telephone+", "+ Mobile+"]]";
	}
	
	
	public Contact validate(Contact c)
	{
		
		int check=0;
		try{
			if(c.First_name==null || c.Last_name==null || c.Date_of_birth==null || c.Email==null )
				throw new NameDOBException("Name OR DOB OR Email is not entered in "+c);
			
			String regex="^(.+)@(.+)$";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(c.Email);
			if(match.matches() == false)
				throw new EmailFormatException("Email is not entered in the proper format--> 'abc@xyz.com'..in "+c);
			
			if(c.Mobile==0 && c.Telephone==0)
				throw new MobileNumberException("Contact Number is not entered in "+c);
			
			///now objects have been validated
			///only validated objects will be pushed onto the stack
			
			return c;
						
		}
		catch(NameDOBException e)
		{
			e.printStackTrace();
		}
		catch(EmailFormatException e)
		{
			e.printStackTrace();
		}
		catch (MobileNumberException e)
		{
			e.printStackTrace();
		}
		return null;
	}
		
	public static void main(String args[])
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date d,d2;
		Contact c;
		try {
			d = sdf.parse("06-05-1995");
			d2=null; //anniversary
			
			//last name not entered //email not in proper format //contact number not entered
			c = new Contact("Alinda","Purple","fernandes",d,d2,"Female","H.No.442","Fatorda","Margao","Goa","India","alindaf@xyz.com","",403602,1234567,0);
			c.validate(c);
			///stack of Contact objects
			
			//telephone number error // validation exception
			Contact c1 = new Contact("Blue",null,"Ivy",sdf.parse("16-06-2011"),d2,"Female","H.No.55",null,null,"LA","US","blueivy@vyd.com","",403602,123456,0);
			Contact c2 = new Contact("green",null,"emarald",sdf.parse("04-12-2000"),d2,"Male","Bldg.No.2",null,null,"Goa","India","axk@fss.com","",403602,7894564,0);
			Contact c3 = new Contact("pink",null,"Purple",sdf.parse("12-06-1991"),d2,"Female","H.No.90","Fatorda","Margao","Goa","India","alin@daf.com","",403602,7894564,0);
			Contact c4 = new Contact("yellow",null,"coldplay",sdf.parse("26-8-1993"),d2,"Male","St.no.442",null,null,"NYC","US","fgd@ggf.com","",403602,7894564,0);
			Contact c5 = new Contact("black",null,"color",sdf.parse("14-9-1987"),d2,"Female","H.No.56","panjim",null,"Goa","India","dff@fgdd.com","",403602,7894564,0);
			
			c1.validate(c1);
			c2.validate(c2);
			c3.validate(c3);
			c4.validate(c4);
			c5.validate(c5);
			
			///initializing stack
			SizedStack <Contact> stack = new SizedStack<>();
			stack.setSize(5);
			stack.push(c); ///in push function(in SizedStack)..if stack size if full..throws an exception
			if(stack.empty()) 
				throw new UninitializedOrEmptyStack("Stack is Uninitialized or is Empty");
			
			
			stack.push(c1);
			stack.push(c2);
			stack.push(c3);
			//stack.push(c4);
			//stack.push(c5);
			
			//invalid contact
			Contact c6 = new Contact("six","six",null,sdf.parse("06-01-1990"),d2,"Male","st.no9","vasco",null,"Goa","India","sdf@ghj.com","",403852,0,7894564);
			
			if(c6.validate(c6) == null)
				throw new ContactInvalidation("Invalid Contact is attempted to be pushed on stack " + c6);
			stack.push(c6);
			
			while(stack.isEmpty()!=true)
				System.out.println(stack.pop());
		}
		
		catch (ParseException e) 
		{
		e.printStackTrace();
		}
		catch (UninitializedOrEmptyStack e) 
		{
			e.printStackTrace();
		}
		catch(ContactInvalidation e)
		{
			e.printStackTrace();
		}
 	}


	
}
