package contacts;

public class MobileNumberException extends Exception{

	public MobileNumberException(String msg)
	{
		super(msg);
	}

}
