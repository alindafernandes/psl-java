package contacts;

import java.util.Stack;

public class SizedStack<Contact> extends Stack<Contact>{
	
	private int maxsize;
	
	
	public int getSize() {
		return maxsize;
	}


	public void setSize(int maxsize) {
		this.maxsize = maxsize;
	}


	@Override
	public Contact push(Contact item)
	{
		//while(this.size()>=maxsize)
			//this.remove(0);
		try{
			if(this.size()>=maxsize)
				throw new  StackFullorUninitialized("Stack is full");
			return super.push(item);
			}
		catch(StackFullorUninitialized e)
		{
			e.printStackTrace();
		}
		return null;
	}
}
