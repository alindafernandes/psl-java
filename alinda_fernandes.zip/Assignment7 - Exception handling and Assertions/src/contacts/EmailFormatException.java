package contacts;

public class EmailFormatException extends Exception{

	public EmailFormatException(String msg)
	{
		super(msg);
	}
}
