package contacts;

public class NameDOBException extends Exception{

	public NameDOBException(String msg)
	{
		super(msg);
	}

}
