import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class EmployeeTest {

	public static void main(String args[])
	{
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
			
			Statement s = con.createStatement();
			String query = "select * from emp";
			ResultSet rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int count = 0;
			while(rs.next())
			{
				count++;
			}
			System.out.println("Number of records in the table : "+ count);
			
			rs.beforeFirst();
			int i=1;
			while(rs.next() && i!=6)
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getDate(5)+" "+rs.getDouble(6)+" "+rs.getDouble(7)+" "+rs.getInt(8));
				i++;
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
	
}
