import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class EmployeeUpdateSalary {
	
	public static void updateSalary(int id)
	{
		Connection con = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest","root","");
			
			Statement s = con.createStatement();
					
			String query = "select * from emp";
			
			ResultSet rs = s.executeQuery(query);
			
			int count=0;
			while(rs.next())
			{
				if(rs.getInt(1) == id)
				{
					count++;
					System.out.println("Current salary : "+rs.getDouble("SAL"));
				}
			}
				
			if(count == 0)
				System.out.println("No record in emp with empno = "+id);
			else
			{
				String q1 = "update emp set SAL = 45500.00 where EMPNO = "+id;
				Statement s1 = con.createStatement();
				s1.executeUpdate(q1);
				
				String q2 = "select * from emp where EMPNO = "+id;
				Statement s2 = con.createStatement();
				ResultSet result = s2.executeQuery(q2);
			
				while(result.next())
				 System.out.println("Updated salary : "+result.getDouble(6));
			}
				
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String args[])
	{		
		Scanner sc = new Scanner(System.in);
			
		System.out.println("Enter empid : ");
		int id = sc.nextInt();
			
		updateSalary(id);
	}
}
