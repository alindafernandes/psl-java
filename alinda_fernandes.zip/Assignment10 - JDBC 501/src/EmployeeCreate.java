import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class EmployeeCreate {

	public static void main(String args[])
	{
		Connection con=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
			
			Statement s = con.createStatement();
			
			String query = "create table emp ( EMPNO int(4) not null,ENAME varchar(10), JOB varchar(9), MGR int(4), HIREDATE date,SAL double(7,2),COMM double(7,2),DEPTNO int(2))";  
			
			s.execute(query);
						
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		finally
		{
			try{
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
	
}
