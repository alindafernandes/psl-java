import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class EmployeeInsert {

	public static void main(String args[])
	{
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
						
			String query1 = "insert into emp value(001,'sam','developer',654,'2015-03-12',25000.00,1599.00,03)";
			String query2 = "insert into emp value(002,'lee','manager',1000,'2012-09-1',35000.00,3599.00,13)";
			String query3 = "insert into emp value(003,'sky','intern',963,'2011-06-2',15000.00,1000.00,20)";
			String query4 = "insert into emp value(004,'jam','front end',66,'2015-09-17',25450.00,1599.00,03)";
			String query5 = "insert into emp value(005,'tom','hr',54,'2009-11-12',30555.00,4599.00,15)";
			String query6 = "insert into emp value(006,'pete','reception',852,'2013-09-22',25500.00,2199.00,10)";
			String query7 = "insert into emp value(007,'alia','developer',100,'2011-11-11',25000.25,2599.00,03)";
			String query8 = "insert into emp value(008,'pink','tester',1063,'2015-12-29',21000.50,2599.00,05)";
			String query9 = "insert into emp value(009,'riri','engineer',45,'2016-10-22',19000.50,1599.00,01)";
			String query10 = "insert into emp value(0010,'lola','trainer',50,'2012-12-12',35000.00,4599.00,15)";
			
			Statement s = con.createStatement();
			
			s.addBatch(query1);
			s.addBatch(query2);
			s.addBatch(query3);
			s.addBatch(query4);
			s.addBatch(query5);
			s.addBatch(query6);
			s.addBatch(query7);
			s.addBatch(query8);
			s.addBatch(query9);
			s.addBatch(query10);
			
			int i[] = s.executeBatch();
			
			for(int c : i)
				System.out.println(c+" record inserted");
		
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		 catch (SQLException e) {
				e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
