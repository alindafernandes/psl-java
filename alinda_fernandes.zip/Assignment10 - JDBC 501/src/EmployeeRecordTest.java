import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class EmployeeRecordTest {

	public static void display(int id)
	{
		Connection con = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest","root","");
			
			Statement s = con.createStatement();
					
			String query = "select * from emp";
			
			ResultSet rs = s.executeQuery(query);
			
			int count =0;
			while(rs.next())
			{
				if(rs.getInt(1) == id)
				{
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getDate(5)+" "+rs.getDouble(6)+" "+rs.getDouble(7)+" "+rs.getInt(8));
					count++;
				}
			}
				
			if(count == 0)
				System.out.println("No record in emp with empno = "+id);
				
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String args[])
	{		
		Scanner sc = new Scanner(System.in);
			
		System.out.println("Enter empid : ");
		int id = sc.nextInt();
			
		display(id);
	}
}
