
public class MainClass {
	public static void main(String args[])
	{
		ThreadNum t = new ThreadNum();
		
		new ProducerThread(t);
				
		new ConsumerThread(t);
		
	}
}
