
public class ThreadDemo extends Thread{
	
	public ThreadDemo(String name)
	{
		//setName(name);
		super(name);
		start();
	}

	@Override
	public void run() {
		System.out.println("Inside the run method");
		
		for(int i =1; i<=10; i++)
		{
			System.out.println(getName()+ " "+ i);
			//System.out.println("Child thread "+i);
		
		//5.Paused state - thread execution is paused
		try {
			sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		}
	}
	
	public static void main(String args[])
	{
		ThreadDemo td1 = new ThreadDemo("A");
		ThreadDemo td2 = new ThreadDemo("B");
		ThreadDemo td3 = new ThreadDemo("C");
		
		td1.setPriority(9);
		td2.setPriority(3);
		td3.setPriority(6);
		
		System.out.println(td1);
		System.out.println(td2);
		System.out.println(td3);
		//td1.start();
		//td2.start();
		//td3.start();
		
	}

}
