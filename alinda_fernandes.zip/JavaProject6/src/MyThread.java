
public class MyThread extends Thread{

	@Override
	public void run() {
		////3.Running - run method is execution
		//System.out.println("Inside the run method");
		for(int i =1; i<=10; i++)
		{
			System.out.println("Child thread "+i);
		
		//5.Paused state - thread execution is paused
		try {
			sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		}
		
	}
	////4.Dead state - thread execution is complete or interrupted or terminated explicitly

	public static void main(String args[])
	{
	////1.NEW BORN STATE - creation on thread object
		MyThread mt = new MyThread(); 
		
	////2.Ready or Runnable - ready to run
		////CPU decides when to call run method once started...and JVM calls run method
		mt.start(); 
		
		for(int i =1; i<=10; i++)
		{
			System.out.println("Main thread "+i);

		
		try {
			sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		}

	}
}
