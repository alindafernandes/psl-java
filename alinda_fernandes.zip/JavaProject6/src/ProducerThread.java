
public class ProducerThread extends Thread{
	
	ThreadNum t;
	
	public ProducerThread(ThreadNum t)
	{
		this.t = t;
		
		start();
	}
	
	@Override
	public void run() {
		int num=1;
		while(num<=2)
			t.setNum(num++);
	}

}
