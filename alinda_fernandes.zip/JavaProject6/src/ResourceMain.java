
public class ResourceMain {

	public static void main(String args[])
	{
		Resource r = new Resource();
		new ResourceThread(r,"Java");
		new ResourceThread(r,"Multithreading");
		new ResourceThread(r,"Example");
		
	}
}
