
public class ConsumerThread extends Thread{

	private ThreadNum td;
	public ConsumerThread(ThreadNum td)
	{
		this.td = td;
		start();
	}
	
	@Override
	public void run() {
		while(true)
			td.getNum();
	}
	
}
