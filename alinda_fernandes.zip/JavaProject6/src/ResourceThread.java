
public class ResourceThread extends Thread{
	Resource resource;
	String msg;
	
	public ResourceThread(Resource resource, String message)
	{
		this.resource=resource;
		msg=message;
		start();
	}

	@Override
	public void run() {
		resource.printMessage(msg);
	}
	
	
}
