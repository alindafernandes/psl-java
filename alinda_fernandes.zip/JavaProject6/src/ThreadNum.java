
public class ThreadNum {

	private int num;
	private boolean flag = true;
		
	///////wait() and notify() have to be written in synchronized methods
	public synchronized int getNum() {
		if(flag == true)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Got : "+num);
		
		///since this method is called in a while loop..this method will be called again...so it still needs to be waiting...so set flag to true
		flag = true;
		notify();
		return num;
	}

	public synchronized void setNum(int num) {
		if(flag == false)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.num = num;
		System.out.println("Set : "+num);
		flag = false; ////not both threads are in wait state
		notify(); /////notifies one waiting thread for that resource
	}
	
}
