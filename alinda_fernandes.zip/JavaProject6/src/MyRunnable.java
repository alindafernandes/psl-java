
public class MyRunnable implements Runnable{

	@Override
	public void run() {
		System.out.println("Inside the run method");
		
		for(int i =1; i<=10; i++)
		{
			System.out.println("Child thread "+i);
		
		//5.Paused state - thread execution is paused
		
		}
	}

	public static void main(String args[])
	{
		MyRunnable mr = new MyRunnable();
		////mr.start();  ////start() method doesnt belong to Runnable, but to Thread class 
		/////Thread t = new Thread(); ////will call run() method in Thread class which doesnt print anything
		////mr.run(); ////will only call run() method and there will be only single threaded and not multithreading
		Thread t = new Thread(mr);
		t.start();
		
		for(int i =1; i<=10; i++)
		{
			System.out.println("Main thread "+i);
		}
	}
	
}
