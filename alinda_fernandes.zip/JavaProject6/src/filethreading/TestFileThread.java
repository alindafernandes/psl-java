package filethreading;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestFileThread{
	private String str;
	private FileOutputStream fo;
	private boolean flag = true;
	private Scanner sc;
	
	
	public synchronized void readInput()
	{
		if(flag == false)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("reading console");
		 sc =new Scanner(System.in);
		str = sc.nextLine();
		
		flag = false;
		notify();
		
	}
	
	public synchronized void writeInput()
	{
		if(flag == true)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("writing file");
		try {
			fo = new FileOutputStream("test",true);
			byte b[] = str.getBytes();
			fo.write(b);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		finally
		{
			try 
				{
					if(fo!=null)
					fo.close();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			
		}
		flag = true;
		notify();
	}
	
	public void scClose()
	{
		sc.close();
	}
	
}
