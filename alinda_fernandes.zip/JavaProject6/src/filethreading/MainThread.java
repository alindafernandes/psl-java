package filethreading;

public class MainThread {

	public static void main(String args[])
	{
		TestFileThread it = new TestFileThread();
		
		new InputThread(it);
		
		new FileThread(it);
		
	}
	
}
