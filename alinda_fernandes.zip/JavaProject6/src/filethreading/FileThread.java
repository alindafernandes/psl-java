package filethreading;

public class FileThread  extends Thread{
	private TestFileThread t;

	public FileThread(TestFileThread t) {
		
		this.t = t;
		start();
	}

	@Override
	public void run() {

		while(true)
		{
			t.writeInput();
		}
		
	}
}
