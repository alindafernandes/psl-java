package filethreading;

public class InputThread  extends Thread{

	private TestFileThread t;
	public InputThread(TestFileThread t)
	{
		this.t=t;
		start();
	}
	
	@Override
	public void run() {
		int num=1;
		while(num<3)
		{
			num++;
			t.readInput();
		}
		
		t.scClose();
	}
	
}
