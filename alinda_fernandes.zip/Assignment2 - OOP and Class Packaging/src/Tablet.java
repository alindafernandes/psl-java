
public class Tablet extends Medicine{

	@Override
	public void displayLabel() {
		System.out.println("Crocin");
		System.out.println("*Store in a cool, dry place");
	}

}
