package Test;

public class PackageTest {
	
	public static void main(String args[])
	{
		PackA a1  = new PackA();
		a1.setA(10);
		a1.setB(40);
		a1.setC("Hello");
		
		System.out.println(a1.geta()+" "+a1.getb()+" "+a1.getc());
	}

}
