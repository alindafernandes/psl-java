
package Test;

public class PackA {
	private int a;
	private int b;
	private String c;
	
	public PackA()
	{}
	
	public void setA(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void setC(String c) {
		this.c = c;
	}

	public PackA(int a, int b, String c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	public int geta()
	{
		return a;
	}
	
	public int getb()
	{
		return b;
	}
	
	public String getc()
	{
		return c;
	}
}