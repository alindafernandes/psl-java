
public class Medicine {
	
	private String name;
	private String addr;
	
	public void displayLabel()
	{
		System.out.println("Anant Pharmaceuticals");
		System.out.println("Verna");
	}

}
