import esg.itp.shape.*;

public class PolyTest {

	public static void main(String args[])
	{
		Square s = new Square(5);
		s.calcArea();
		s.calcPeri();
		s.display();
		
		Rectangle r = new Rectangle(10,20);
		r.calcArea();
		r.calcPeri();
		r.display();
	}
}
