import Test.PackA;


public class PackTest {
	public static void main(String args[])
	{
		PackA a1  = new PackA(23,45,"alinda");
		
		System.out.println(a1.geta()+" "+a1.getb()+" "+a1.getc());
	}

}
