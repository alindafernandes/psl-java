import java.util.Scanner;

import com.persistent.app.*;

public class GreetTest {
	public static void main(String args[])
	{
		String sname;
		Scanner sc=new Scanner(System.in);
		sname = sc.nextLine();
		
		Greeter g = new Greeter(sname);
		g.sayHello();
		
		String mess[]={"keep calm","dont shout","smile","eat well","be nice"};
		
		Advisor a = new Advisor(mess);
		a.getAdvice();
		
		g.goodBye();
	}

}
