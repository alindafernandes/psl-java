package com.persistent.app;

public class Greeter{

	private String name;
	
	public Greeter(String aName)
	{
		this.name = aName;
	}
	
	public void sayHello()
	{
		System.out.println("Hello...!"+name);
	}
	
	public void goodBye()
	{
		System.out.println("Good Bye...!"+name);
	}
}
