
package com.persistent.app;

import java.util.Random;

public class Advisor {

	private String message[] = new String[5];
	
	public Advisor(String m[])
	{
			for(int i=0;i<m.length;i++)
				message[i] = m[i];
	}
	
	public void getAdvice()
	{
		Random r = new Random();
		int val = r.nextInt(5);
		System.out.println(this.message[val]);
	}
}
