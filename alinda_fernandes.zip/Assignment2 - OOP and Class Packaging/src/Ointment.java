
public class Ointment extends Medicine{

	public void displayLabel()
	{
		System.out.println("Thromophob");
		System.out.println("*For external use only");
	}
}
