import java.util.Random;



public class TestMedicine {

	public static void main(String args[])
	{
		Medicine m[]  =new Medicine[10];
		Random r =new Random();
		int val = r.nextInt(4); ///generates numbers between 0 and x....will not include x
		m[0] = new Medicine();
		m[1] = new Tablet();
		m[2] = new Syrup();
		m[3] = new Ointment();
		
		m[val].displayLabel();
	
	}
}
