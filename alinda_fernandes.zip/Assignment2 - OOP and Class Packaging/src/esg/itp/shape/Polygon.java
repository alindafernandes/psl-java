package esg.itp.shape;

public interface Polygon {
	public abstract void calcArea( );	
	public abstract void calcPeri( ); 	
	public abstract void display( );
}
