package esg.itp.shape;

public class Rectangle implements Polygon{
	private float length;
	private float breadth;
	private float a;
	private float p;
	public Rectangle(int len,int bre)
	{
		length = len;
		breadth = bre;
	}
	@Override
	public void calcArea() {
		a=length*breadth;
	}
	@Override
	public void calcPeri() {
		p=(length*2)+(breadth*2);
	}
	@Override
	public void display() {
		System.out.println("Area of Rect "+a);
		System.out.println("Perimeter of Rect "+p);
	}
}
