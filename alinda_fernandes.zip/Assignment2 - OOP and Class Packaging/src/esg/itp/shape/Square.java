package esg.itp.shape;

public class Square implements Polygon{
	private float side;
	private float a;
	private float p;
	public Square(float s)
	{
		side =s;
	}
	@Override
	public void calcArea() {
		a=side*side;
	}
	@Override
	public void calcPeri() {
		p=4*side;
	}
	@Override
	public void display() {
		System.out.println("Area of square "+a);
		System.out.println("Perimeter of square "+p);
	}
	
}
