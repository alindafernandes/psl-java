
public class Syrup extends Medicine{

	public void displayLabel()
	{
		System.out.println("Ascoril");
		System.out.println("*Consume prescribed dosage");
	}
}
