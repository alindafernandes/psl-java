import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class StatementTest {

	public static void main(String args[])
	{
		Connection con = null;
		try {
			///1.load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			///2.establish connection
			///con= DriverManager.getConnection(url, username, password);
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
			System.out.println("connected");
			/*
			String query = "insert into products value(101,'laptop',25000.00)";
			
			Statement st = con.createStatement();
			int i = st.executeUpdate(query); ///returns number of rows affected by that query
			if(i>0)
			{
				System.out.println("Record is inserted");
			}
			*/
			
			///select statement
			String query = "select * from products";
			
			Statement st = con.createStatement();
			int i = st.executeUpdate(query); ///returns number of rows affected by that query
			if(i>0)
			{
				System.out.println("Record is inserted");
			}
						
			///user enters query
			/*
			System.out.println("Enter query ");
			Scanner sc = new Scanner(System.in);
			String query = sc.nextLine();
			Statement st = con.createStatement();
			int i=st.executeUpdate(query);
			if(i>0)
			{
				System.out.println("Record is inserted");
			}
			*/
			
			///user enters product details
			/*
			System.out.println("Enter query ");
			Scanner sc = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			Scanner sc3 = new Scanner(System.in);
			String query = "insert into products value("+sc.nextInt()+",'"+sc2.nextLine()+"',"+sc3.nextDouble()+")";
			Statement st = con.createStatement();
			int i=st.executeUpdate(query);
			if(i>0)
			{
				System.out.println("Record is inserted");
			}
			*/
			
			///update a query
			/*
			//update an entry
			String query = "update products set name = '1TB HD' where id=102";
			Statement st = con.createStatement();
			int i = st.executeUpdate(query); ///returns number of rows affected by that query
			if(i>0)
			{
				System.out.println("Record is updated");
			}
			*/
			
			///delete a query
			/*
			//delete an entry
			String query = "delete from products where id = 101";
			Statement st = con.createStatement();
			int i = st.executeUpdate(query); ///returns number of rows affected by that query
			if(i>0)
			{
				System.out.println("Record is deleted");
			}
			
			*/
			
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		finally
		{
			try{
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
	
}
