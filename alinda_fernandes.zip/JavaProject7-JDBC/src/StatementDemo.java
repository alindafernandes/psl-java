import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementDemo {
	public static void main(String args[])
	{
	
	Connection con = null;
	try {
		///1.load the driver
		Class.forName("com.mysql.jdbc.Driver");
		
		///2.establish connection
		///con= DriverManager.getConnection(url, username, password);
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
		System.out.println("connected");
		Statement statement = con.createStatement();
		///select statement
		String query;
		//query = "select * from products";
		query = "select * from products where id=102";
		ResultSet resultset = statement.executeQuery(query);
		
		while(resultset.next())
		{
			System.out.println(resultset.getInt(1)); ///1 is the column number(id)
			System.out.println(resultset.getString(2)); ////2 is the column number(name)
			System.out.println(resultset.getDouble(3));
			System.out.println("....................");
		}
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	}
}
