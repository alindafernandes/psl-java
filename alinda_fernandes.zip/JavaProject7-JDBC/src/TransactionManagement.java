import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class TransactionManagement {
	public static void main(String args[])
	{
	////only operations which will cause addition or modification of db will be a transaction
		
	Connection con = null;
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
		System.out.println("connected");
		
		con.setAutoCommit(false); ///by setting this to false, whatever changes are made will not be automatically reflected into the db
		////this is to control what changes are made into the db...we choose to commit when we want to
		
		/*
		String query = "insert into products values(107,'TV',20000.00)";
		Statement s = con.createStatement();
		int i=s.executeUpdate(query);
		if(i>0)
			System.out.println("Record inserted");
		else
			System.out.println("Record not inserted");
		
		con.commit(); ////if this is not added when autoCommit()is set to false...changes wont be updated to db
		*/
		/*		
		String query = "insert into products values(108,'camera',55000.00)";
		Statement s = con.createStatement();
		int i=s.executeUpdate(query);
		if(i>0)
			System.out.println("Record inserted");
		else
			System.out.println("Record not inserted");
		
		con.rollback();
		*/
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	}
}
