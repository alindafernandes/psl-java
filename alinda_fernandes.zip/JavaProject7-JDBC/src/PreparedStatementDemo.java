import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class PreparedStatementDemo {
	public static void main(String args[])
	{
	
	Connection con = null;
	try {
		///1.load the driver
		Class.forName("com.mysql.jdbc.Driver");
		
		///2.establish connection
		///con= DriverManager.getConnection(url, username, password);
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
		System.out.println("connected");
		
		
		String query;
		//insert
		//query = "insert into products values(?,?,?)";
		
		//update
		query = "update products set name = ? where id=105";
		
		//delete
		query = "delete from products where id=?";

		
		PreparedStatement preparedst = con.prepareStatement(query); ///doesnt need to get compiled everytime it is reused
		//preparedst.setInt(1, 105);
		preparedst.setInt(1, 105); ////delete
		//preparedst.setString(2, "Mobile");
		//preparedst.setString(1, "SmartPhone"); //// update ///question mark number///not column number
		//preparedst.setDouble(3, 15000.00);
		int i=preparedst.executeUpdate();
		
		if(i>0)
			System.out.println("Record Updated");
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	}
}
