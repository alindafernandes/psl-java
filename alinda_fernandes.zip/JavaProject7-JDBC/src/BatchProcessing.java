import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class BatchProcessing {
	public static void main(String args[])
	{
	////only operations which will cause addition or modification of db will be a transaction
		
	Connection con = null;
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
		System.out.println("connected");
		
		Statement s = con.createStatement();
		
		con.setAutoCommit(false);
		
		String query1 = "insert into products values(108,'book',500.00)";
		String query2 = "insert into products values(109,'picture',1000.00)";
		String query3 = "update products set name = 'Pen' where id=108";
		
		s.addBatch(query1);
		s.addBatch(query2);
		s.addBatch(query3);
		
		int count[] = s.executeBatch();
		for(int c : count)
			System.out.println(c);

		con.commit();
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	}
}
