import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class ResultSetMetaDataDemo {
	public static void main(String args[])
	{
	
	Connection con = null;
	try {
		///1.load the driver
		Class.forName("com.mysql.jdbc.Driver");
		
		///2.establish connection
		///con= DriverManager.getConnection(url, username, password);
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtest", "root", "");
		System.out.println("connected");
		
		
		String query;
		query = "select * from products";

		Statement s = con.createStatement();
		ResultSet rs = s.executeQuery(query);

		ResultSetMetaData rsmd = rs.getMetaData();
		
		System.out.println("Total Columns : "+ rsmd.getColumnCount());
		System.out.println("Column Name of 1st column : "+ rsmd.getColumnName(1));
		System.out.println("Column Type Name of 1st column : "+ rsmd.getColumnTypeName(1));
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	}
}
