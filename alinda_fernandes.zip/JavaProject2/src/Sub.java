
public class Sub extends Super{
	
	private int age;
	private String loc;
	
	public Sub(int srNo, String name, int age, String loc)
	{
		super(srNo,name);
		this.age=age;
		this.loc=loc;
	}

	public int getAge()
	{
		return age;
	}
	
	public String getLoc()
	{
		return loc;
	}
	
}
