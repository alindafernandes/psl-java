
public class InheritanceMain {

	public static void main(String args[])
	{
		Person p = new Person("Pink","US");
		//p.setName("Pink");
		//p.setAddr("US");
		
		System.out.println("Name  :"+p.getName());
		System.out.println("Addr  :"+p.getAddr());
		
		Employee e = new Employee("green","us",21,"goa");
		//e.setName("Green");
		//e.setAddr("US");
		//e.setEmpId(21);
		//e.setEmpLoc("LA");
		System.out.println("Name  :"+e.getName());
		System.out.println("Addr  :"+e.getAddr());
		System.out.println("EmpID  :"+e.getEmpId());
		System.out.println("Loc  :"+e.getEmpLoc());
		
	}
}
