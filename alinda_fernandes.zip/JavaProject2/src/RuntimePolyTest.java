
public class RuntimePolyTest {

	public static void main(String args[])
	{
		
		///initialization of object p...for polygon or rectangle or triangle is decided at runtime
		
		Polygon p;
		//p= new Polygon();
		//p.calcArea(12d, 4d);
		//p.display();
		
		p=new Rectangle(); 	///upcasting!
		p.calcArea(12d,4d);
		p.display();
		
		//p.dispArea(); ////dispArea() is in Rectangle class not Polygon(Super) ..hence compiler gives error
		
		Rectangle r = (Rectangle)p; ///DOWNCASTING....Making p into type Rectangle object and storing it in r
		Rectangle r1 = new Rectangle();
		
		
		r.dispArea();
		r1.dispArea();
		
		p=new Triangle(); 	///upcasting!
		p.calcArea(12d,4d);
		p.display();
		
	}
}
