
public class Cat implements Animal{

	public void eat()
	{
		System.out.println("Fish");
	}

	@Override
	public void speak() {
		System.out.println("Meow");
	}
	
}
