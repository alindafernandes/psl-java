
public class InterfaceMain {

	public static void main(String args[])
	{
		Animal a;
		
		a = new Cat();
		System.out.println("Cat:");
		a.eat();
		a.speak();
		
		System.out.println("");
		
		a = new Lion();
		System.out.println("Lion:");
		a.eat();
		a.speak();
	}
}
