
public abstract  class Polygon {
double area;
/*public void calcArea(double b, double l)
{
	area = b+l;
}*/

public abstract  void calcArea(double b, double l);

public void display()
{
	System.out.println("Area : "+area);
}
}
