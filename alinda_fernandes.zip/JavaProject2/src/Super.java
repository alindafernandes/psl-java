
public class Super {

	private int srNo;
	private String name;
	public Super(int srNo, String name) {
		super();
		this.srNo = srNo;
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	public int getSrno()
	{
		return srNo;
	}
	
}
