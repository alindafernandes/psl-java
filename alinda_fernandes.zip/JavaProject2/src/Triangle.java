
public class Triangle extends Polygon{

	//@Override
	public void calcArea(double b, double l) {
		area = 0.5*b*l;
	}


}
