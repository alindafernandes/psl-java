
public class Employee extends Person {
 private int empId;
 private String empLoc;
 
 
public Employee(String name, String addr,int empId, String empLoc) {
	super(name,addr);///has to be the first statement in the constructor
	this.empId = empId;
	this.empLoc = empLoc;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpLoc() {
	return empLoc;
}
public void setEmpLoc(String empLoc) {
	this.empLoc = empLoc;
}
 
}
