
public class StaticDemo {

	static int staticVar;
	int num;
	public static void print()
	{
		staticVar = 20;
		StaticDemo d = new StaticDemo();
		d.num = 5;
		System.out.println(staticVar);
	}
	public  void display()
	{
		staticVar = 10;
		num = 5;
		System.out.println(staticVar);
	}
}
