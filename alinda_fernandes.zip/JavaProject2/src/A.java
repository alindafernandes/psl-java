
class A1 {
	public A1()
	{
		System.out.println("A1");
		
	}

}
class B extends A1 {
	public B()
	{
		System.out.println("B");
		
	}

}
class C extends B {
	public C()
	{
		System.out.println("C");
		
	}

}

public class A
{
	public static void main(String args[])
	{
		new C();
	}
}