
public class StaticTest {
	public static void main(String args[])
	{
		StaticDemo s = new StaticDemo();
		s.print();
		s.display();
	}
}
