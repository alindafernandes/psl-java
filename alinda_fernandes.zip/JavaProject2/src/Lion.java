
public class Lion implements Animal{
	public void eat()
	{
		System.out.println("Meat");
	}

	@Override
	public void speak() {
		System.out.println("Roar");
	}
}
