
public class Rectangle extends Polygon {

	@Override
	public void calcArea(double b, double l) {
		
		area = b*l;
	}
	
	public void dispArea()
	{
		System.out.println("Area : "+area);
	}

}
