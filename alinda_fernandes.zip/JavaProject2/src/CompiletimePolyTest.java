
public class CompiletimePolyTest {

	public void add(){}
	
	void add(int a){}
	
	int add(int a, float b){return 1;}
	
	int add(float a, int b){return 0;}
	
	public static void main(String args[])
	{
		CompiletimePolyTest test = new CompiletimePolyTest();
		test.add();
		test.add(1);
		test.add(1.1f,3);
		test.add(9,4.0f);
	}
}
