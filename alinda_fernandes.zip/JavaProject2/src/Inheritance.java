
public class Inheritance {

	public static void main(String args[])
	{
		Super s1 = new Super(1,"red");
		
		System.out.println("Sr.No."+" "+"Name"+" "+"Age"+" "+"Loc");
		System.out.println(s1.getSrno()+"      "+s1.getName());
		
		Sub s = new Sub(2,"pink",21,"goa");
		System.out.println(s.getSrno()+"      "+s.getName()+" "+s.getAge()+" "+s.getLoc());
	
	}
}
