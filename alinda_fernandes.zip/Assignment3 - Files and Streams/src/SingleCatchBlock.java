public class SingleCatchBlock {
	public static void main(String[] args) {
		int b =10, x[] = { 10, 20, 30 }; 
		try { 
			String str = "hello";
			System.out.println(str.charAt(15));
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try{
			int c = x[4]/b; 
			System.out.println(c);
		
		} 
		catch(ArithmeticException | ArrayIndexOutOfBoundsException 
				| StringIndexOutOfBoundsException  e) 
		{ 
			System.out.println(e); 
		} 
		
	}
}