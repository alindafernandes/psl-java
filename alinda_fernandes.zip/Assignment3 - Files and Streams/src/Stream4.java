import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Stream4 
{	
	static String makeReverse(String str)
		{
			String words[] = str.split(" ");
			int len;
			String text="";
			
			for(String s : words)
			{
				char c[]= new char[10];
				for(int i=0,j=1;i<s.length();i++,++j)
				{
					c[i]=s.charAt(s.length()-j);
				}
				String str1 = new String(c);
				text=text.concat(str1);
			}
			return text;
		}
		
		public static void main(String args[])
		{
			BufferedReader br;
			try {
				br = new BufferedReader(new FileReader("reverse"));
				
				StringBuffer sb = new StringBuffer();
				
				String line=null;
				String msg=null;
				try {
					while((line=br.readLine())!=null)
					{
						sb.append(line).append("\n");
						msg = line;
					}
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				
				System.out.println(msg);
				String aa=makeReverse(msg);
				System.out.println(aa);
				
			} catch (FileNotFoundException e1) {
				
				e1.printStackTrace();
			}
			
		}
			
}
