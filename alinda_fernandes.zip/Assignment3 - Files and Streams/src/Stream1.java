import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Stream1 {

	public static void main(String[] args) {
		
		FileInputStream fi = null;
		FileOutputStream fo  = null;
		
		System.out.println("Enter source file : ");
		Scanner sc = new Scanner(System.in);
		String src = sc.nextLine();		
		
		try{
			fi = new FileInputStream("C:/Users/alinda_fernandes/Assignment3/src/"+src);
		}
		catch (FileNotFoundException e) {
			System.out.println("Source file not found");
		}
		
		System.out.println("Enter destination file : ");
		Scanner sc2 = new Scanner(System.in);
		String dest = sc2.nextLine();		
		
		try{
			File f = new File("C:/Users/alinda_fernandes/Assignment3/src/"+dest);
			fo = new FileOutputStream(f);
			
			System.out.println("Do you want to overwrite (yes/no)?");
			Scanner sc3 = new Scanner(System.in);
			String ans = sc.nextLine();	
			
			if(ans.equals("yes"))
			{
				System.out.println("Contents of destination file:");
				int data;
				while((data = fi.read()) != -1)
				{
					fo.write(data); ///writing to destination file
					System.out.print((char)data);
				}
			}
			
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
		
		
		finally{
			try {
				fo.close();
				fi.close();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
