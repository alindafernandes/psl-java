public class ExceptionHandlingDemo1 {
	public static void main(String[] args) {
		int a,b,c;
		a = 10;
		b = 0;
		try
		{
			int arr[] = new int[5];
			arr[1] = 20;
			System.out.println(arr[1]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Wrong array index");
			e.printStackTrace();
		}
		
		try
		{
				c = a/b;
			System.out.println("c is: " + c);			
		}
		catch(ArithmeticException e)
		{
			System.out.println("Value of b can not be 0");
			e.printStackTrace();
		}
			
		try{
				String str = "Hello";
				char ch = str.charAt(10);
				System.out.println("ch: " + ch);
			}
			
			catch(Exception e)
		{
			System.out.println("Error");
			e.printStackTrace();
		}
			finally
			{
			System.out.println("Inside finally block");
		}
	}
}
