import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Stream2 {

	public static void main(String[] args) {
		System.out.println("Enter contents of source");
		Scanner sc = new Scanner(System.in);
		String msg = sc.nextLine();
		File f = new File("C:/Users/alinda_fernandes/Assignment3/src/io.txt");
		
		FileOutputStream fo = null;
		
		long l;
		try{
			fo = new FileOutputStream(f);
			byte b [] = msg.getBytes();
			
			fo.write(b);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		finally{
			try{
				l=f.length();
				System.out.println("The size of io.txt is : " +l);
				fo.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		System.out.println("The contents of io.txt : " );
		FileInputStream fi = null;
		int d;
		try
		{
			fi = new FileInputStream(f);
			while((d=fi.read())!=-1)
			{
				System.out.print((char)d);
			}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				fi.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		f.delete();
		System.out.println("");
		System.out.println("File io.txt is deleted");
		
	}
}
