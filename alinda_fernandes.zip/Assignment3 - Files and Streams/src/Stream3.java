import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Stream3 {

	static int check(String sentence,String word)
	{
		int check=0;
		String words[] = sentence.split(" ");
		for(String s : words)
		{
			if(s.equals(word))
				check++;
		}
		return check;
	}
	
	public static void main(String args[])
	{
		
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("yellow"));
		
		StringBuffer sb = new StringBuffer();
		
		String line=null;
		String msg=null;
		try {
			while((line=br.readLine())!=null)
			{
				sb.append(line).append("\n");
				msg = line;
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
		System.out.println("the word 'color' has appeared "+check(msg,"color")+" times");
		
	} catch (FileNotFoundException e1) {
		
		e1.printStackTrace();
	}
		

		
	}
		
}
