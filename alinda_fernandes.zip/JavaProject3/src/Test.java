import static java.lang.System.out;

public class Test {

	public static void  main(String args[])
	{
		out.println("blah blah");
		out.print("lalala");
		
	}
}
