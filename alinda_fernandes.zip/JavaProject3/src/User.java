
public class User {
private int age;

public int getAge() {
	return age;
}

public void setAge(int age) {
	
	if(age<18)
	{
		try{
			throw new AgeException("Age cant be less than 18");
		}
		catch(Exception e){e.printStackTrace();}
	}
	else
		this.age=age;
}

public static void main(String args[])
{
	User user = new User();
	user.setAge(21);
	System.out.println(user.getAge());
}
}
