
public class AgeException extends Exception
{
	public AgeException(String msg)
	{
		super(msg); ////sends the msg to Exception Super class and displays this message
	}

}
