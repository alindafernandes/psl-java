
public class Test {

	private int intVar;
	private long longVar;
	private float floatVar;
	private String stringVar;
	private char charVar;
	private boolean boolVar;
	
	public static void main (String args[])
	{
		Test test = new Test();
		System.out.println(test.intVar);
		System.out.println(test.longVar);
		System.out.println(test.floatVar);
		System.out.println(test.stringVar);
		System.out.println(test.charVar);
		System.out.println(test.boolVar);
	}
}
