
public class Person {
	private String name;	//PersonTest can't access 'em
	private int age;
	
	
	public Person() ////gets invoked every time an object is created
	{
		System.out.println("!!!!!!!!!!constructor");
		name = "ali";
		age = 21;
	}
	
	public Person(String name, int age) 
	{
		System.out.println("!!!!constructor!!!!");
		this.name = name;
		this.age = age;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) ///values sent in from PersonTest
	{
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	//setter and getter methods
	
}
