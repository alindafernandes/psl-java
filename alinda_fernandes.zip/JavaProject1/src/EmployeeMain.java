
public class EmployeeMain {
	
	public static void main(String args[])
	{
		Employee employee = new Employee(101, "Randall","Pune");
		System.out.println(employee);
		
		Employee employees[] = new Employee[1];
		employees[0] = new Employee(102,"pink","goa");
		employees[1] = new Employee(102,"green","us");
		employees[2] = new Employee(102,"yellow","asia");
		
		for(Employee emp : employees)
		{
			System.out.println(emp);
		}
		
		for(int i =0; i < employees.length; i++)
		{
			System.out.println(employees[i]);
		}
	}
}
