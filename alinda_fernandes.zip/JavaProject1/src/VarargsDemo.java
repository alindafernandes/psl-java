
public class VarargsDemo {
	
	public void print(int...intArray)// intArray[])
	{
		for(int i : intArray)
		{
			System.out.println(i);
		}
		System.out.println("...........");
	}
	
	

	public static void main(String args[])
	{
		VarargsDemo demo = new VarargsDemo();
		/*int intArr[] = {1,2,3};
		demo.print(intArr);
		
		int intArr1[] = {1,2,3,4,5};
		demo.print(intArr1);
		
		int intArr2[] = {1,2,3,4,5,6,7,8,9,10};
		demo.print(intArr2);
		*/
		
		demo.print(1,2,3);
		demo.print(1,2,3,5,6,7,8);
		demo.print(1,2,3,4,5,6,7,8,9,10);
	}

}
