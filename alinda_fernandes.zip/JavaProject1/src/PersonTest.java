
public class PersonTest {
public static void main(String args[])
{
	Person p1 = new Person("Randal",21);
	//p1.name = "Randal";
	//p1.age = 21;
	
	//p1.setName("Randal");
	//p1.setAge(21);
	
	//System.out.println("Name : "+p1.name);
	//System.out.println("Age : "+p1.age);
	
	
	
	System.out.println("Name : "+p1.getName());
	System.out.println("Age : "+p1.getAge());
	
	/*Person p2 = new Person();
	p2.name = "Sally";
	p2.age = 25;
	
	System.out.println("Name : "+p2.name);
	System.out.println("Age : "+p2.age);*/
	
}
}
