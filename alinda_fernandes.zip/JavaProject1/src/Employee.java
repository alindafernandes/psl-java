
public class Employee {

	private int emid;
	private String name;
	private String location;
	public Employee(int emid, String name, String location) {
		super();
		this.emid = emid;
		this.name = name;
		this.location = location;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "emp id " + emid + " name " + name  + " location " + location;
	}
			
}
