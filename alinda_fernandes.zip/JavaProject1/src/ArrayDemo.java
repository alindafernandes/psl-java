
public class ArrayDemo {

	public static void main(String args[])
	{
		
		int array[];
		array = new int[5];
		
		array[0]=10;
		array[1]=20;
		array[2]=30;
		array[3]=40;
		array[4]=50;
		
		for(int value : array)   //runs the length of the array and value at each index is stored in 'value'
		{
			System.out.println(value);
		}
	}
	
}
