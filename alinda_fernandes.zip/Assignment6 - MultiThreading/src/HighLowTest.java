
public class HighLowTest extends Thread{
	public HighLowTest(String name)
	{
		setName(name); ///sets the names of the threads
	}
	
	@Override
	public void run() {
		System.out.println("inside run method : ");
		
		
		for(int i=0;i<5;i++)
		{
			System.out.println(getName()+"  "+getPriority()+"  " +i);
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}

	public static void main(String args[])
	{
		HighLowTest hlt1 = new HighLowTest("A");
		HighLowTest hlt2 = new HighLowTest("B");
		HighLowTest hlt3 = new HighLowTest("C");
		
		hlt1.setPriority(5);
		hlt2.setPriority(1); //highest priority thread
		hlt3.setPriority(10);
		
		hlt1.start();
		hlt2.start();
		hlt3.start();
		
	}
	
}
