
public class HighPriorityTest extends Thread{

	public HighPriorityTest(String name)
	{
		setName(name); ///sets the names of the threads
		
	}
	
	@Override
	public void run() {
		System.out.println("inside run method : ");
		
		for(int i=0;i<5;i++)
		{
			System.out.println(getName()+"  "+getPriority()+"  " +i);
		}
	}

	public static void main(String args[])
	{
		HighPriorityTest hpt1 = new HighPriorityTest("A");
		HighPriorityTest hpt2 = new HighPriorityTest("B");
		HighPriorityTest hpt3 = new HighPriorityTest("C");
		
		hpt1.setPriority(4);
		hpt2.setPriority(9); //highest priority thread
		hpt3.setPriority(1);
		
		hpt1.start();
		hpt2.start();
		hpt3.start();
	}
	
	
}
