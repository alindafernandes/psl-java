package question6;

public class ReadName extends Thread{
	private FileClass fc;
	public ReadName(FileClass fc)
	{
		this.fc=fc;
		start();
	}

	@Override
	public void run() {
		int n=0;
		while(n<2)
		{
			fc.readInput();
			n++;
		}
	}
	
}
