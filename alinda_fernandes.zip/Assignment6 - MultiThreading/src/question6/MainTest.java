package question6;

public class MainTest {

	public static void main(String args[])
	{
		FileClass fc = new FileClass();
		
		new ReadName(fc).setName("Thread A");
		new ReadFiles(fc).setName("Thread B");
	}
	
}
