package question6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileClass {

	private String str;
	private boolean flag=true;
	
	
	public synchronized void readInput()
	{
		if(flag==false)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println("Enter file name ");
		Scanner sc = new Scanner(System.in);
		str = sc.nextLine();
		flag=false;
		notify();
	}
	
	
	public synchronized void readFile()
	{
			if(flag==true)
				try {
					wait();
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			
			boolean status=false;
			BufferedReader br;
			try {
				br = new BufferedReader(new FileReader(str));
				
				StringBuffer sb = new StringBuffer();
				
				String line=null;
				String msg=null;
				try {
					while((line=br.readLine())!=null)
					{
						sb.append(line).append(" ");
						msg = line;
						System.out.println(str);
						System.out.println(msg);
					}
					
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
			} catch (FileNotFoundException e1) {
				
				e1.printStackTrace();
			}
			flag=true;
			notify();
		
	}
}
