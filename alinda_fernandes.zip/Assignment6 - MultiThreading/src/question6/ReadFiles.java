package question6;

public class ReadFiles extends Thread{

	private FileClass fc;
	public ReadFiles(FileClass fc)
	{
		this.fc=fc;
		start();
	}

	@Override
	public void run() {
		while(true)
		{
			fc.readFile();
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			System.out.println(getName()+" is awake");
		}
	}
	
}
