package question7;

public class FactTest {
public static void main(String args[])
{
	
	CalcFact cf = new CalcFact();
	
	new ReadFile(cf);
	
	new Factorial(cf);
	
}
}
