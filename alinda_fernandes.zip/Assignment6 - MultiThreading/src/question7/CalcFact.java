package question7;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CalcFact {

	private int fact;
	private boolean flag=true;
	private int num[] = new int[5];
	private int i=0;
	
	public synchronized void readText()
	{
		if(flag==false)
		{
			try {
				wait();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
			BufferedReader br;
			try {
				br = new BufferedReader(new FileReader("Numbers"));
				
				StringBuffer sb = new StringBuffer();
				
				String line=null;
				
				
				try {
					while((line=br.readLine())!=null)
					{
						sb.append(line).append("\n");
						num[i] = Integer.parseInt(line);
						System.out.println(line);
						i++;
					}
						
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
			} catch (FileNotFoundException e1) {
				
				e1.printStackTrace();
			}
			
		flag=false;
		notify();
	}
	
	public synchronized void calcFactorial()
	{
		if(flag==true)
		{
			try {
				wait();
			} catch (InterruptedException e1) {
				
				e1.printStackTrace();
			}
		}
		int f=0; 
		for(int i = 0; i<num.length;i++)
		{
			f=num[i];
			fact=1;
			for(int j=1;j<=f;j++)
			{
				fact=fact*j;
			}
			System.out.println("Factorial of "+f+" is " + fact);
		}
		
		flag=true;
		notify();
	}
	
}
