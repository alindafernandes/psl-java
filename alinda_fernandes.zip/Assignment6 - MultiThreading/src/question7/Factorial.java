package question7;

public class Factorial extends Thread{
private CalcFact c;

public Factorial(CalcFact c) {
	
	this.c = c;
	start();
}

@Override
public void run() {
	
		c.calcFactorial();
}

}
