package question7;

public class ReadFile extends Thread{
	private CalcFact c;

	public ReadFile(CalcFact c) {
		
		this.c = c;
		start();
	}

	@Override
	public void run() 
	{
		c.readText();
	}

}
