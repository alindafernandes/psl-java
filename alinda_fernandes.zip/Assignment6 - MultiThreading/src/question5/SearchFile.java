package question5;

public class SearchFile extends Thread{

	private SearchInput st;

	public SearchFile(SearchInput st) {
		
		this.st = st;
		start();
	}

	@Override
	public void run() {
		
		while(true)
		{
			System.out.println(getName());
			st.readFile();
		}
	}
}
