package question5;

public class ReadString extends Thread{

	private SearchInput st;

	public ReadString(SearchInput st) {
		
		this.st = st;
		start();
	}

	@Override
	public void run() {
		int n=0;
		while(n<4)
		{
			System.out.println(getName());
			st.readInput();
			n++;
		}
	}
}
