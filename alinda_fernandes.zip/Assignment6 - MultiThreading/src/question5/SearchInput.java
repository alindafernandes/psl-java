package question5;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class SearchInput {

	private String str;
	private FileInputStream fi;
	private boolean flag=true;
	
	public synchronized void readInput()
	{
		if(flag==false)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		Scanner sc = new Scanner(System.in);
		str = sc.nextLine();
		flag=false;
		notify();
		
	}
	
	public synchronized void readFile()
	{	
		if(flag==true)
			try {
				wait();
			} catch (InterruptedException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		
		boolean status=false;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("file"));
			
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String msg=null;
			try {
				while((line=br.readLine())!=null)
				{
					sb.append(line).append(" ");
					msg = line;
					System.out.println(msg);
				}
				
				
				String words[] = msg.split(" ");
				int len;
				String text="";
				
				for(String s : words)
				{
					if(s.equals(str))
						status=true;
				}
				
				System.out.println(str+" : status : "+status);
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
		flag=true;
		notify();
	}
	
}
