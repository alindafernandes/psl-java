package question5;

public class StatusTest {
	
	public static void main(String args[])
	{
		SearchInput st = new SearchInput();
		
		new ReadString(st).setName("Thread A"); 
		new SearchFile(st).setName("Thread B"); 
			
	}

}
