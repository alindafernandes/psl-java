package question3and4;

public class TestMain {

	public static void main(String args[])
	{
		Storage s = new Storage();
		
		new Counter(s);
		new Printer(s);
	}
	
}
