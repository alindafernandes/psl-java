package question3and4;

public class Counter extends Thread{

	private Storage s;
	public Counter(Storage s)
	{
		this.s = s;
		start();
	}
	@Override
	public void run() {
		int n=0;
		while(n<10)
			s.setNum(n++);
	}
	
}
