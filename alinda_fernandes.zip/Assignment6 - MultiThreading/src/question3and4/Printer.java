package question3and4;

public class Printer extends Thread{
	private Storage s;
	
	public Printer(Storage s)
	{
		this.s=s;
		start();
	}

	@Override
	public void run() {
		while(true)
			System.out.println(s.getNum());
	}
}
