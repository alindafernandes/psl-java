import java.util.Date;
import java.util.Comparator;


public class DateComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		Date d1 = e1.getDate();
		Date d2 = e2.getDate();
		return d1.compareTo(d2);
	}
	

}
