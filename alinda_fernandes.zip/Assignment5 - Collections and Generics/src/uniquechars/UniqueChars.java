package uniquechars;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class UniqueChars {

	public static Map<String,Set<Character>> map = new HashMap<>();
	
	public static int getUniqueChars(String input)
	{
		if(map.isEmpty() == false)
		{
			if(map.containsKey(input))
			{
				System.out.println("*");
				return map.get(input).size();
			}
		}
		char ch[] = input.toCharArray();
		
		Set<Character> set = new TreeSet<>();
		
		for(char c : ch)
			set.add(c);
		
		map.put(input, set);
		
		System.out.println(set);
		return set.size();
	}
	
	public static void main(String args[])
	{
	String input = "Can you can a can as a CANNER can?";
	int count;
	count = getUniqueChars(input);
	System.out.println(input+" "+count);
	count = getUniqueChars(input);
	System.out.println(input+" "+count);
	input = "World wide WEB";
	count = getUniqueChars(input);
	System.out.println(input+" "+count);
	count = getUniqueChars(input);
	System.out.println(input+" "+count);
	
	}
}
