import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class GenericPrint {
	
	public static <T>  void print(Collection <T> c)
	{
		System.out.println(c);
	}
	
	public static void main(String args[])
	{
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(45);
		list.add(50);
		
		print(list);
		
		Set<Integer> set = new TreeSet<>();////sorts and prints in ascending order
		set.add(80);
		set.add(40);
		set.add(90);
		set.add(20);
		set.add(60);
		set.add(50);
		
		print(set);
		
		Set<Student> set1 = new HashSet<>();
		set1.add(new Student(1,"R"));
		set1.add(new Student(3,"S"));
		set1.add(new Student(2,"A"));
		set1.add(new Student(4,"B"));
		
		
		print(set1);
		
	}

}
