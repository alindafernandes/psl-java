import java.util.Comparator;


public class EmpIdComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee s1, Employee s2) {
		Integer emp1 = s1.getEmpid();
		Integer emp2 = s2.getEmpid();
		
		return emp1.compareTo(emp2);
	}

}
