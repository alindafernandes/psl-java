import java.util.Date;


public class Employee {
	
	private int empId;
	private String name;
	public Date d;
	public Employee(int empId, String name, Date d) {
		super();
		this.empId = empId;
		this.name = name;
		this.d = d;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", d=" + d + "]";
	}
	
public int getEmpid()
{
	return empId;
}

public Date getDate()
{
	return d;
}
}
