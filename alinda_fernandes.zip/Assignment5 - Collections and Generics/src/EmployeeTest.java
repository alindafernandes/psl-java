
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class EmployeeTest {

	public static void main(String args[])
	{
		Set<Employee> set = new TreeSet<>(new EmpIdComparator());
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date d;
		try {
			d = sdf.parse("23-11-2016");
			set.add(new Employee(21,"alinda",d));
			d = sdf.parse("12-1-2016");
			set.add(new Employee(31,"rhea",d));
			d = sdf.parse("19-8-2014");
			set.add(new Employee(41,"josh",d));
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		int ch;
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("Enter your choice : ");
			System.out.println("1. Display all employee Information. ");
			System.out.println("2. Display all employees who have joined organization before 01-08-2015. ");
			System.out.println("3. Display all employees who have completed six month in organization. ");
			System.out.println("4. Exit");
			
			ch = sc.nextInt();
			switch(ch)
			{
			case 1: ///Display all employees
					System.out.println(set);
				break;
			case 2: ///display all employees who joined before 01-08-2015
				try {
					d = sdf.parse("01-08-2015");
					
					Iterator <Employee> itr = set.iterator();
					while(itr.hasNext())
					{
						Employee emp =itr.next();
						if(emp.d.before(d))
							System.out.println(emp);	
					}
					
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
					
				break;
			case 3: ///display all employees who have completed 6 months
				try {
					
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.DATE,-180);
					
					d = sdf.parse(cal.get(Calendar.DATE)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+(cal.get(Calendar.YEAR)));
					
					Iterator <Employee> itr = set.iterator();
					while(itr.hasNext())
					{
						Employee emp =itr.next();
						if(emp.d.before(d))
							System.out.println(emp);	
					}
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				break;
			case 4: ///exit
				break;
			default:
				break;
			}
			
			
			}while(ch!=4);
		
		sc.close();
	}
	
}
