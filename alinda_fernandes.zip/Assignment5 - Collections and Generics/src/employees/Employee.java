package employees;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Employee {

	private int empid;
	
	public Employee(int id)
	{
		empid=id;
	}
	
	@Override
	public String toString() {
		
		return "Employee id : "+empid;
	}
	
	public static void main(String args[])
	{
		Map<Employee,List<Vehicles>> map = new HashMap<>();
		List <Vehicles> list = new ArrayList<>();
		list.add(new Vehicles ("Car"));
		list.add(new Vehicles ("2 wheeler"));
				
		map.put(new Employee(001),list );
		
		List <Vehicles> list2 = new ArrayList<>();
		list2.add(new Vehicles ("2 wheeler"));
		list2.add(new Vehicles ("2 wheeler"));
				
		map.put(new Employee(002),list2 );
		
		List <Vehicles> list3 = new ArrayList<>();
		list3.add(new Vehicles ("Car"));
				
		map.put(new Employee(003),list3 );
		
		List <Vehicles> list4 = new ArrayList<>();
		list4.add(new Vehicles ("2 wheeler"));
		list4.add(new Vehicles ("Car"));
		list4.add(new Vehicles ("Car"));
		
		map.put(new Employee(004),list4 );
		
		for(Map.Entry<Employee, List<Vehicles>> entry : map.entrySet())
			System.out.println(entry.getKey()+"  "+entry.getValue());
	}

}
