package employees;

public class Vehicles {

	private String vehicleType;

	public Vehicles(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	@Override
	public String toString()
	{
		return "Vehicle : "+vehicleType;
	}
	
}
