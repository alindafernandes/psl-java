package citymap;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class CityStateMap {
	
	public static void main(String args[])
	{
		Map<String,String> map = new TreeMap<>();
			
		try {
			BufferedReader br = new BufferedReader(new FileReader("map"));
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String s[]  = new String[2];
			while((line=br.readLine())!=null)
			{
				sb.append(line).append("\n");
				s = line.split(" ");
				map.put(s[0], s[1]);
			}
			System.out.println(sb);
			System.out.println(map);
						
			Scanner sc = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			Scanner sc3 = new Scanner(System.in);
			Scanner sc4 = new Scanner(System.in);
			Scanner sc5 = new Scanner(System.in);
			
			int ch ;
			String state,city;
			Set<String> set = map.keySet();
			Collection<String> c = map.values();
			do{
				System.out.println("Enter your choice : ");
				System.out.println("1. Get all cities");
				System.out.println("2. Get All states");
				System.out.println("3. Get cities for a state");
				System.out.println("4. Add new city state pair");
				System.out.println("5. Delete all the cities for a given state");
				System.out.println("6. Exit");
				
				ch = sc.nextInt();
						
				switch(ch)
				{
				case 1: ///Get all cities
					
					
					System.out.println(set);
					
					break;
				case 2: ///Get All states
					
					System.out.println(c);
					
					break;
				case 3: ///Get cities for a state
					
					System.out.println("Enter a State ");
					state = sc2.nextLine();
					
					for(String k : set)
					{
						if(map.get(k).compareTo(state) == 0)
						{
							System.out.print(k+" ");
							System.out.println(map.get(k));
						}
					}
					
					break;
				case 4: ///Add new city state pair
					
					System.out.println("Enter a City ");
					city = sc3.nextLine();
					
					System.out.println("Enter a State ");
					state = sc4.nextLine();
					
					map.put(city, state);
					
					break;
				case 5: ///Delete all the cities for a given state

					System.out.println("Enter a State ");
					state = sc5.nextLine();
					
					 Set<String> a = new HashSet<>();
					 int i =0;
					for(String k2 : set)
					{
						if(map.get(k2).compareTo(state) == 0)
						{
							a.add(k2);
							i++;
						}
						
					}
					
					if(a.isEmpty()!=true)
					{
						for(String b : a)
						{
							System.out.println(b +" "+map.get(b)+" was deleted");
							map.remove(b);
						}
					}
					else
						System.out.println("There is no entry with this state");
					break;
				case 6: ///exit
					break;
				
				default:
					break;
				}
				
				
				}while(ch!=6);
				
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
		
	}
	
}
