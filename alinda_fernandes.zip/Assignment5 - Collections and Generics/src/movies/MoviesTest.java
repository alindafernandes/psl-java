package movies;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MoviesTest {

	public static List<Movies> createMovieList()
	{
		List<Movies> list= new ArrayList<>();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date d;
		try {
			d=sdf.parse("01-03-2016");
			list.add(new Movies("ABCD","Hindi",d,"Remo Dsouza","Prabhu Deva",190));
			d=sdf.parse("16-01-2015");
			list.add(new Movies("Nachuya Kumpasar","Konkani",d,"Aaron","Chetan",120));
			d=sdf.parse("06-05-1995");
			list.add(new Movies("A Nightmare Before Christmas","English",d,"Tim Burton","Tim Burton",125));
			d=sdf.parse("09-12-1989");
			list.add(new Movies("Breakfast Club","English",d,"Judd Nelson","Simple Minds",145));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	public static void sortByLanguage(List<Movies> movieList)
	{
		
		System.out.println("Sort by Language ");
		
		movieList.sort(new LanguageComparator());
		
		System.out.println(movieList);
	}
	
	public static void sortByDuration(List<Movies> movieList)
	{
		System.out.println("Sort by Duration ");
		
		movieList.sort(new DurationComparator());
		
		System.out.println(movieList);
	}
	public static void sortByLanguageAndReleaseDate(List<Movies> movieList) 
	{
		System.out.println("Sort by Language and Release Date ");
		
		movieList.sort(new LanguageComparator());
		
		System.out.println(movieList);
	}

	public static void main(String args[])
	{
		List<Movies> list= new ArrayList<>();
		list=createMovieList();
		
		sortByLanguage(list);
		
		sortByDuration(list);
		
		sortByLanguageAndReleaseDate(list);
	}
	
}
