package movies;

import java.util.Comparator;

public class LanguageComparator implements Comparator<Movies> {

	@Override
	public int compare(Movies m1, Movies m2) {
		String s1 = m1.getlang();
		String s2 = m2.getlang();	
				
		if((s1.compareTo(s2))==0) ////if two movies have the same language
		{
			ReleaseDateComparator r = new ReleaseDateComparator();
			return r.compare(m1, m2);
			
		}
		
		return s1.compareTo(s2);
	}

}
