package movies;

import java.util.Comparator;
import java.util.Date;

public class ReleaseDateComparator implements Comparator<Movies>{
	@Override
	public int compare(Movies m1, Movies m2) {
		Date d1 = m1.getreleasedate();
		Date d2 = m2.getreleasedate();
			
		return d1.compareTo(d2);
			
	}
}
