package movies;

import java.util.Comparator;

public class DurationComparator implements Comparator<Movies>{
	@Override
	public int compare(Movies m1, Movies m2) {
		Integer d1 = m1.getduration();
		Integer d2 = m2.getduration();
		return d1.compareTo(d2);
	}
}
