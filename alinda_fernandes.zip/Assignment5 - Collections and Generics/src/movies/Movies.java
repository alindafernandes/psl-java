package movies;

import java.util.Date;

public class Movies {
	
	
	public Movies(String name, String language, Date releaseDate,
			String director, String producer, int duration) {
		super();
		this.name = name;
		this.language = language;
		this.releaseDate = releaseDate;
		this.director = director;
		this.producer = producer;
		this.duration = duration;
	}
	private String name, language;
	private Date releaseDate;
	private String director, producer;
	private int duration; 
	
	@Override
	public String toString() {
		return "Movies [name=" + name + ", language=" + language
				+ ", releaseDate=" + releaseDate + ", director=" + director
				+ ", producer=" + producer + ", duration=" + duration + "]";
	}
	
	
	public String getlang()
	{
		return language;
	}
	public int getduration()
	{
		return duration;
	}
	public Date getreleasedate()
	{
		return releaseDate;
	}
	
}
