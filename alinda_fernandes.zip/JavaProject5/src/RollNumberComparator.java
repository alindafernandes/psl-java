import java.util.Comparator;

public class RollNumberComparator implements Comparator<Student>
{
	
	@Override
	public int compare(Student s1, Student s2) {
		// TODO Auto-generated method stub
		Integer roll1 = s1.getRollno();
		Integer roll2 = s2.getRollno();
		
		return roll1.compareTo(roll2);
	}

}
