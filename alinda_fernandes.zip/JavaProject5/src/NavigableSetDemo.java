import java.util.Iterator;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;


public class NavigableSetDemo {

	public static void main(String args[])
	{
		NavigableSet<Integer> navset = new TreeSet<>();
		navset.add(34);
		navset.add(89);
		navset.add(5);
		navset.add(45);
		navset.add(20);
		navset.add(30);
		
		System.out.println(navset);
		System.out.println("..............");
		
		Iterator<Integer>itr = navset.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		System.out.println("..............");
		
		Iterator<Integer>itr2 = navset.descendingIterator();
		while(itr2.hasNext())
			System.out.println(itr2.next());
		System.out.println("..............");
		
		////headset(max_val/upper_limit) ///by default upperlimit not included
		NavigableSet<Integer> sorted = (NavigableSet<Integer>) navset.headSet(45);
		System.out.println(sorted);
		System.out.println("..............");
		
		NavigableSet<Integer> sorted2 = (NavigableSet<Integer>) navset.headSet(45, true);
		System.out.println(sorted2);
		System.out.println("..............");
		
		NavigableSet<Integer> sorted3 = (NavigableSet<Integer>) navset.headSet(45, false);
		System.out.println(sorted3);
		System.out.println("..............");
		
		///tailset(min_val/lower_limit) ///by default lower limit is included
		NavigableSet<Integer> sorted4 = (NavigableSet<Integer>) navset.tailSet(10);
		System.out.println(sorted4);
		System.out.println("..............");
		
		
		///subSet(upperlimit,lowerlimit)
		NavigableSet<Integer> sorted5 = (NavigableSet<Integer>) navset.subSet(20, true, 45, false);
		System.out.println(sorted5);
		System.out.println("..............");
		
		
	}
}
