import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
public class MapDemo {
public static void main(String args[])
{
	Map<Integer, String> map = new HashMap<>();
	map.put(123, "Alinda");
	map.put(345, "Pritiva");
	map.put(123, "Kiyara"); ////overwrites Alinda...since keys are unique
	map.put(245, "Pink");
	
	System.out.println(map);
	
	Set<Integer> key = map.keySet();
	System.out.println(key);
	
	Collection<String> val= map.values();
	System.out.println(val);
	
	for(Integer k : key)
	{
		System.out.print(k);
		System.out.println(" "+map.get(k));
	}
}
}
