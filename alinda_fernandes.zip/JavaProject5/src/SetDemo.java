import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;


public class SetDemo {
	public static void main(String args[])
	{
		Set<Integer> set = new HashSet<>(); ////UnOrdered...doesnt keep track of the order of insertion
		set.add(80);
		set.add(40);
		set.add(90);
		set.add(20);
		set.add(60);
		set.add(50);
		System.out.println("HashSet : "+set);
		
		set = new TreeSet<>();////sorts and prints in ascending order
		set.add(80);
		set.add(40);
		set.add(90);
		set.add(20);
		set.add(60);
		set.add(50);
		System.out.println("TreeSet : "+set);
		
		set = new LinkedHashSet<>();///Ordered...keeps track of order of insertion
		set.add(80);
		set.add(40);
		set.add(90);
		set.add(20);
		set.add(60);
		set.add(50);
		System.out.println("LinkedHashSet : "+set);
	}
}
