import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;


public class StudentSet {
public static void main(String args[])
{
	Set<Student> set = new HashSet<>();
	set.add(new Student(1,"R"));
	///set.add(5,(6,"J"));  
	set.add(new Student(3,"S"));
	set.add(new Student(2,"A"));
	set.add(new Student(4,"B"));
	
	System.out.println(set);
	
	set = new TreeSet<>(new RollNumberComparator());
	///throws an error...not a predefined object...it doesnt know which parameter to compare
	set.add(new Student(1,"R"));
	set.add(new Student(3,"S"));
	set.add(new Student(2,"A"));
	set.add(new Student(4,"B"));
		
	System.out.println(set);
	
}
}
