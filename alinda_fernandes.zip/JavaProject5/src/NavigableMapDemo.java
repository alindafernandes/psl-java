
import java.util.Iterator;
import java.util.NavigableMap;
import java.util.TreeMap;


public class NavigableMapDemo {
	public static void main(String args[])
	{
		NavigableMap<Integer,String> navmap = new TreeMap<>();
		navmap.put(21, "Alinda");
		navmap.put(1, "Pink");
		navmap.put(56, "carrot");
		navmap.put(45, "Yellow");
		navmap.put(21, "Cold");
		navmap.put(66, "orange");
		navmap.put(30, "green");
		
		System.out.println(navmap);
		System.out.println("..............");
		
		System.out.println("contains key=56? : "+navmap.containsKey(56));
		System.out.println("value of key=56? : "+navmap.get(56));
		System.out.println("replace value of key=56 : "+navmap.replace(56, "bLUE"));
		System.out.println(navmap);
		System.out.println("..............");
		System.out.println("ceiling of 40 : "+navmap.ceilingKey(40));
		System.out.println("lowest key in map : "+navmap.firstKey());
		System.out.println("floor of 40 : "+navmap.floorKey(40));
		System.out.println("highest key in map : "+navmap.lastKey());
		System.out.println("contains value = green? : "+navmap.containsValue("green"));
		System.out.println("submap(21,45) : "+navmap.subMap(21,45 ));
		System.out.println("descending order of map : "+navmap.descendingMap());
		System.out.println("headmap till 56 : "+navmap.headMap(56, true));
		System.out.println("remove 56 : "+navmap.remove(56));
		System.out.println(navmap);
		System.out.println("..............");
		System.out.println("pollFirstEntry : "+navmap.pollFirstEntry());
		System.out.println(navmap);
		System.out.println("..............");
		System.out.println("pollLastEntry : "+navmap.pollLastEntry());
		System.out.println(navmap);
		System.out.println("..............");
		System.out.println("Clear Map ... ");
		navmap.clear();
		System.out.println("Map empty? : "+navmap.isEmpty());
	}
}
