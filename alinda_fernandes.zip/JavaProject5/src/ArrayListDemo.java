import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class ArrayListDemo {

	public static void main(String args[])
	{
		List<Integer> list = new ArrayList<Integer>();
		
		//till jdk 1.4
		list.add(new Integer(50)); ////boxing
		
		///since jdk 1.5
		///AutoBoxing...converting primitive type into Wrapper Class object...
		///since Collections can't work with primitives
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(30);///allows duplicates
		
		System.out.println(list.size()+" "+list);
		
		///insertion
		list.add(0, 90);
		System.out.println(list.size()+" "+list);
		
		System.out.println(list.contains(30));
		
		list.remove(4);
		System.out.println(list.size()+" "+list);
		
		System.out.println("index 2 : "+list.get(2));
		
		
		int a=0;
		for(int i : list)
			a+=i;
		System.out.println("TOTAL : "+a);
		
		int b=0;
		for(int i=0; i<list.size();i++)
			b+=list.get(i);
		System.out.println("TOTAL : "+b);
		
		int c=0;
		Iterator <Integer>itr = list.iterator();
		while(itr.hasNext())
			c+=itr.next();
		System.out.println("TOTAL : "+c);
		
		Collections.sort(list);
		System.out.println(list);
		
		Collections.reverse(list);
		System.out.println(list);
		
	}
}
